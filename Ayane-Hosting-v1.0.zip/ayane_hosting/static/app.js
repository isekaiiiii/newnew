const state = { csrf: '', admin: null, servers: [], admins: [], config: null, view: 'dashboard', pendingDelete: null, setupRequired: false, language: localStorage.getItem('ayane-language') || 'vi' };
const $ = (id) => document.getElementById(id);
const tr = (key) => (translations[state.language] && translations[state.language][key]) || translations.en[key] || key;
const translations = {
  vi: {
    private_panel:'KHU VỰC QUẢN TRỊ RIÊNG',username:'Tên đăng nhập',password:'Mật khẩu',admin_only:'Chỉ Admin · Phiên đăng nhập được bảo vệ',workspace:'KHÔNG GIAN LÀM VIỆC',overview:'Tổng quan',servers:'Máy chủ',admins:'Quản trị viên',system:'Hệ thống & tích hợp',secure_edge:'Kết nối biên an toàn',checking:'Đang kiểm tra…',administrator:'Quản trị viên',control_plane:'TRUNG TÂM ĐIỀU KHIỂN',overview_label:'TỔNG QUAN HẠ TẦNG',control_center:'Trung tâm điều khiển',welcome_line:'Quản lý runtime, tunnel và hạ tầng tại một nơi.',create_server:'Tạo server',total_servers:'TỔNG SERVER',python_instances:'SERVER PYTHON',node_instances:'SERVER NODE.JS',active_tunnels:'TUNNEL HOẠT ĐỘNG',provisioned:'Các instance đã tạo',cloudflare_routes:'Các tuyến Cloudflare',resources:'TÀI NGUYÊN',recent_servers:'Server gần đây',view_all:'Xem tất cả',server_directory:'Danh sách server',server_directory_sub:'Các ứng dụng đã được khởi tạo',live:'TRỰC TIẾP',server:'SERVER',runtime:'RUNTIME',hostname:'TÊN MIỀN',status:'TRẠNG THÁI',nothing_here:'Chưa có dữ liệu',create_first:'Tạo server đầu tiên để hiển thị tại đây.',create_first_server:'Tạo server đầu tiên',quick_actions:'THAO TÁC NHANH',get_things_done:'Bắt đầu công việc',deploy_new:'Triển khai server mới',deploy_new_sub:'Khởi chạy Python hoặc Node.js',check_integrations:'Kiểm tra tích hợp',check_integrations_sub:'Kiểm tra API và kết nối tunnel',runtime_mix:'PHÂN BỐ RUNTIME',language_distribution:'Tỷ lệ ngôn ngữ',runtime_note:'Chọn runtime phù hợp với từng ứng dụng.',instance_management:'QUẢN LÝ INSTANCE',your_servers:'Máy chủ của bạn',servers_subtitle:'Tạo, kiểm tra và truy cập mọi ứng dụng.',all_instances:'Tất cả instance',resources_col:'TÀI NGUYÊN',public_endpoint:'ĐỊA CHỈ CÔNG KHAI',actions:'THAO TÁC',no_servers:'Không tìm thấy server',no_servers_sub:'Server mới sẽ xuất hiện tại đây sau khi tạo.',resource_note:'Giới hạn 0 nghĩa là không giới hạn ở cấp server trong Pterodactyl. Dung lượng thực tế vẫn phụ thuộc phần cứng node và allocation.',access_control:'QUẢN LÝ TRUY CẬP',admin_accounts:'Tài khoản Admin',admin_subtitle:'Chỉ quản trị viên mới được truy cập bảng điều khiển hosting.',add_admin:'Thêm Admin',authorized_admins:'Quản trị viên được phép',no_customer_accounts:'Không có tài khoản khách hàng hoặc người dùng công khai',system_status:'TRẠNG THÁI HỆ THỐNG',integrations:'Tích hợp',integrations_sub:'Trạng thái kết nối hạ tầng hosting.',test_connections:'Kiểm tra kết nối',not_checked:'Chưa kiểm tra',ptero_sub:'Tạo và khởi chạy server Python / Node.js độc lập.',cf_sub:'Xuất bản từng server bằng tunnel riêng và bản ghi DNS.',configuration:'CẤU HÌNH',environment_settings:'Thiết lập môi trường',env_intro:'Thông tin bí mật được lưu trong file .env trên máy chủ, không gửi ra trình duyệt.',domain_warning:'Cloudflare yêu cầu domain gốc đã được thêm vào Cloudflare và nameserver trỏ về Cloudflare. Domain DuckDNS không thể được quản lý qua API zone của Cloudflare.',private_infrastructure:'HẠ TẦNG RIÊNG TƯ',provision_instance:'KHỞI TẠO INSTANCE',server_name:'Tên server',subdomain_prefix:'Tiền tố subdomain',subdomain_hint:'Chỉ dùng chữ thường, số và dấu gạch ngang.',choose_runtime:'Chọn runtime',resource_limits:'Giới hạn tài nguyên',zero_unlimited:'0 = không giới hạn',capacity_note:'0 bỏ giới hạn riêng của server; phần cứng node vẫn áp dụng.',cancel:'Hủy',provision_server:'Khởi tạo server',create_admin:'Tạo Admin',danger_zone:'VÙNG NGUY HIỂM',delete_server:'Xóa server?',delete_permanently:'Xóa vĩnh viễn',deploying:'Đang tạo server và tunnel…',deleting:'Đang xóa server…',copy:'Sao chép',open_panel:'Mở Panel',reconnect:'Kết nối lại',retry_tunnel:'Thử tạo Tunnel lại',delete:'Xóa',created:'Đã tạo server.',delete_confirm:'Thao tác này sẽ xóa server khỏi Pterodactyl, gỡ tunnel và xóa bản ghi DNS. Không thể hoàn tác.',server_count:'server',admin_created:'Đã tạo tài khoản Admin.',tunnel_pending:'Server đã tạo nhưng connector tunnel chưa chạy. Hãy kiểm tra Docker.',active:'Hoạt động',pending_connector:'Chờ connector',tunnel_failed:'Tunnel lỗi',cleanup_pending:'Chờ dọn dẹp',provisioning:'Đang tạo',search:'Tìm server…',current:'ĐANG DÙNG',first_admin:'Tạo Admin đầu tiên',setup_desc:'Tạo tài khoản quản trị đầu tiên. Không có đăng ký người dùng thông thường.',login:'Đăng nhập Admin',login_desc:'Đăng nhập để quản lý hạ tầng Ayane Hosting.',first_setup:'THIẾT LẬP BAN ĐẦU',admin_login:'ADMIN ACCESS',invalid:'Thông tin không hợp lệ.',resource_memory:'RAM',admin_created_at:'Tạo lúc',name_required:'Nhập tên server.',slug_required:'Nhập subdomain.',ptero_not_ready:'Chưa cấu hình Pterodactyl hoặc Cloudflare. Mở System & integrations để xem hướng dẫn.',runtime_python:'Python',runtime_node:'Node.js'
  },
  en: {
    private_panel:'PRIVATE ADMIN PANEL',username:'Username',password:'Password',admin_only:'Admin access only · Session protected',workspace:'WORKSPACE',overview:'Overview',servers:'Servers',admins:'Administrators',system:'System & integrations',secure_edge:'Secure edge connection',checking:'Checking…',administrator:'Administrator',control_plane:'CONTROL PLANE',overview_label:'YOUR INFRASTRUCTURE AT A GLANCE',control_center:'Control center',welcome_line:'Manage your runtimes, tunnels and infrastructure from one place.',create_server:'Create server',total_servers:'TOTAL SERVERS',python_instances:'PYTHON INSTANCES',node_instances:'NODE.JS INSTANCES',active_tunnels:'ACTIVE TUNNELS',provisioned:'Provisioned instances',cloudflare_routes:'Cloudflare routes',resources:'RESOURCES',recent_servers:'Recent servers',view_all:'View all',server_directory:'Server directory',server_directory_sub:'Your provisioned application instances',live:'LIVE',server:'SERVER',runtime:'RUNTIME',hostname:'HOSTNAME',status:'STATUS',nothing_here:'Nothing here yet',create_first:'Create your first server to see it here.',create_first_server:'Create your first server',quick_actions:'QUICK ACTIONS',get_things_done:'Get things done',deploy_new:'Deploy a new server',deploy_new_sub:'Launch a Python or Node.js instance',check_integrations:'Check integrations',check_integrations_sub:'Verify API and tunnel connectivity',runtime_mix:'RUNTIME MIX',language_distribution:'Language distribution',runtime_note:'Choose the runtime that best fits each application.',instance_management:'INSTANCE MANAGEMENT',your_servers:'Your servers',servers_subtitle:'Provision, inspect and access every application instance.',all_instances:'All instances',resources_col:'RESOURCES',public_endpoint:'PUBLIC ENDPOINT',actions:'ACTIONS',no_servers:'No servers found',no_servers_sub:'Your new instances will appear here after provisioning.',resource_note:'A limit of 0 means unlimited at the server level in Pterodactyl. Actual capacity still depends on your node hardware and allocations.',access_control:'ACCESS CONTROL',admin_accounts:'Admin accounts',admin_subtitle:'Only administrators can access this hosting control plane.',add_admin:'Add admin',authorized_admins:'Authorized administrators',no_customer_accounts:'No customer or public user accounts',system_status:'SYSTEM STATUS',integrations:'Integrations',integrations_sub:'Connection health for your hosting infrastructure.',test_connections:'Test connections',not_checked:'Not checked',ptero_sub:'Creates and provisions isolated Python / Node.js servers.',cf_sub:'Publishes each server through its own named tunnel and DNS record.',configuration:'CONFIGURATION',environment_settings:'Environment settings',env_intro:'Secrets are kept on the server in the .env file and are never sent to the browser.',domain_warning:'Cloudflare requires your base domain to be onboarded in Cloudflare with its nameservers pointing to Cloudflare. DuckDNS domains cannot be managed through your Cloudflare zone API.',private_infrastructure:'PRIVATE INFRASTRUCTURE',provision_instance:'PROVISION INSTANCE',server_name:'Server name',subdomain_prefix:'Subdomain prefix',subdomain_hint:'Lowercase letters, numbers and hyphens only.',choose_runtime:'Choose runtime',resource_limits:'Resource limits',zero_unlimited:'0 = unlimited',capacity_note:'0 removes the per-server limit; physical node capacity still applies.',cancel:'Cancel',provision_server:'Provision server',create_admin:'Create admin',danger_zone:'DANGER ZONE',delete_server:'Delete server?',delete_permanently:'Delete permanently',deploying:'Creating server and tunnel…',deleting:'Deleting server…',copy:'Copy',open_panel:'Open Panel',reconnect:'Reconnect',retry_tunnel:'Retry tunnel',delete:'Delete',created:'Server created.',delete_confirm:'This removes the server from Pterodactyl, deletes its tunnel and DNS record. This cannot be undone.',server_count:'servers',admin_created:'Administrator created.',tunnel_pending:'Server created, but the tunnel connector is not running. Check Docker.',active:'Active',pending_connector:'Connector pending',tunnel_failed:'Tunnel failed',cleanup_pending:'Cleanup pending',provisioning:'Provisioning',search:'Search servers…',current:'CURRENT',first_admin:'Create your first admin',setup_desc:'Create the first administrator account. There is no public user registration.',login:'Admin login',login_desc:'Sign in to manage Ayane Hosting infrastructure.',first_setup:'FIRST-TIME SETUP',admin_login:'ADMIN ACCESS',invalid:'Invalid information.',resource_memory:'RAM',admin_created_at:'Created',name_required:'Enter a server name.',slug_required:'Enter a subdomain.',ptero_not_ready:'Pterodactyl or Cloudflare is not configured. Open System & integrations for details.',runtime_python:'Python',runtime_node:'Node.js'
  }
};

async function api(path, options = {}) {
  const headers = { ...(options.headers || {}) };
  if (options.body && !headers['Content-Type']) headers['Content-Type'] = 'application/json';
  if (state.csrf && !['GET','HEAD'].includes((options.method || 'GET').toUpperCase())) headers['X-CSRF-Token'] = state.csrf;
  const response = await fetch(path, { credentials: 'same-origin', ...options, headers });
  let data = {};
  try { data = await response.json(); } catch (_) {}
  if (!response.ok) throw new Error(data.detail || data.message || `HTTP ${response.status}`);
  return data;
}
function toast(message, type='success') {
  const el = document.createElement('div'); el.className = `toast ${type}`; el.textContent = message;
  $('toast-root').appendChild(el); setTimeout(() => el.remove(), 4400);
}
function setLanguage(lang) {
  state.language = lang; localStorage.setItem('ayane-language', lang);
  document.documentElement.lang = lang;
  document.querySelectorAll('[data-i18n]').forEach(el => { const k=el.dataset.i18n; if (translations[lang][k]) el.textContent = translations[lang][k]; });
  const languageLabel = lang==='vi' ? '<b>VI</b> <i></i> EN' : 'VI <i></i> <b>EN</b>';
  $('language-toggle').innerHTML = languageLabel;
  $('language-toggle-main').innerHTML = languageLabel;
  if (!state.admin) renderAuth(state.setupRequired); else { renderServers(); renderAdmins(); updateHeadings(); }
}
function renderAuth(setup=false) {
  $('auth-screen').classList.remove('hidden'); $('app-shell').classList.add('hidden');
  const setupMode = setup; state.setupRequired = setupMode;
  $('auth-eyebrow').textContent = setupMode ? tr('first_setup') : tr('admin_login');
  $('auth-title').textContent = setupMode ? tr('first_admin') : tr('login');
  $('auth-description').textContent = setupMode ? tr('setup_desc') : tr('login_desc');
  $('auth-submit').innerHTML = `${setupMode ? tr('first_admin') : tr('login')} <span>↗</span>`;
  $('auth-password').minLength = setupMode ? 12 : 1;
  $('auth-form').dataset.mode = setupMode ? 'setup' : 'login';
}
function showApp(admin) {
  state.admin = admin; state.setupRequired = false; $('auth-screen').classList.add('hidden'); $('app-shell').classList.remove('hidden');
  $('admin-name').textContent = admin.username; $('admin-avatar').textContent = admin.username[0].toUpperCase(); $('top-avatar').textContent = admin.username[0].toUpperCase();
}
function updateHeadings() {
  const names = {dashboard:tr('overview'),servers:tr('servers'),admins:tr('admins'),system:tr('system')};
  $('topbar-section').textContent = names[state.view] || names.dashboard;
  document.querySelectorAll('.nav-item').forEach(btn => btn.classList.toggle('active', btn.dataset.view === state.view));
}
function navigate(view) {
  state.view=view;
  document.querySelectorAll('.view-section').forEach(el=>el.classList.add('hidden'));
  $(`view-${view}`).classList.remove('hidden');
  updateHeadings();
  if(view==='admins') loadAdmins(); if(view==='system') loadConfig();
}
function fmtDate(value) { try { return new Date(value.replace(' ','T')+'Z').toLocaleDateString(state.language==='vi'?'vi-VN':'en-US',{year:'numeric',month:'short',day:'numeric'}); } catch(_) { return value || ''; } }
function runtimeLabel(lang){return lang==='python'?'Python':'Node.js'}
function statusLabel(status){const map={active:tr('active'),pending_connector:tr('pending_connector'),tunnel_failed:tr('tunnel_failed'),cleanup_pending:tr('cleanup_pending'),tunnel_provisioning:tr('provisioning'),provisioning:tr('provisioning')};return map[status]||status}
function safeText(value){return String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function serverActions(s, compact=false){
  const open = s.panel_url ? `<a class="mini-action" href="${safeText(s.panel_url)}" target="_blank" rel="noopener">↗ ${tr('open_panel')}</a>` : '';
  const reconnect = s.status!=='active' && s.status!=='cleanup_pending' ? `<button class="mini-action" data-reconnect="${s.id}">↻ ${tr(s.tunnel_id?'reconnect':'retry_tunnel')}</button>` : '';
  const copy = `<button class="mini-action" data-copy="${safeText(s.hostname)}">⧉ ${tr('copy')}</button>`;
  const del = `<button class="mini-action danger" data-delete="${s.id}">⌫ ${tr('delete')}</button>`;
  return compact ? `${open}${copy}` : `${open}${copy}${reconnect}${del}`;
}
function serverRow(s, compact=false){
  const resource = `${s.memory===0?'∞':s.memory+' MB'} · ${s.disk===0?'∞':s.disk+' MB'} · CPU ${s.cpu===0?'∞':s.cpu+'%'}`;
  return `<tr><td><div class="server-cell"><span class="server-icon">▤</span><span><strong>${safeText(s.name)}</strong><small>${safeText(s.identifier)}</small></span></div></td><td><span class="runtime-pill ${s.language}"><i></i>${runtimeLabel(s.language)}</span></td>${compact?'':`<td><span class="resource-text">${resource}</span></td>`}<td><a class="hostname-cell" href="https://${safeText(s.hostname)}" target="_blank" rel="noopener noreferrer">${safeText(s.hostname)} ↗</a></td><td><span class="state-pill ${s.status==='active'?'active':(s.status==='tunnel_failed'||s.status==='cleanup_pending'?'warning':'')}"><i></i>${statusLabel(s.status)}</span></td><td><div class="row-actions">${serverActions(s,compact)}</div></td></tr>`;
}
function renderServers(){
  const python=state.servers.filter(s=>s.language==='python').length, node=state.servers.length-python;
  $('stat-total').textContent=state.servers.length; $('stat-python').textContent=python; $('stat-node').textContent=node; $('stat-tunnels').textContent=state.servers.filter(s=>s.status==='active').length;
  $('nav-server-count').textContent=state.servers.length; $('server-count-caption').textContent=`${state.servers.length} ${tr('server_count')}`;
  $('recent-server-rows').innerHTML=state.servers.slice(0,5).map(s=>serverRow(s,true)).join('');
  $('server-rows').innerHTML=filterServers(state.servers).map(s=>serverRow(s,false)).join('');
  $('recent-empty').classList.toggle('hidden',state.servers.length>0); $('servers-empty').classList.toggle('hidden',filterServers(state.servers).length>0);
  const total=state.servers.length || 1, p=python/total*100, n=node/total*100;
  $('python-bar').style.width=`${p}%`; $('node-bar').style.width=`${n}%`; $('python-percent').textContent=`${Math.round(p)}%`; $('node-percent').textContent=`${Math.round(n)}%`;
  $('sidebar-tunnel-status').innerHTML=`<i class="status-dot ${state.servers.some(s=>s.status==='active')?'good':''}"></i><span>${state.servers.some(s=>s.status==='active')?tr('active'):'No active tunnels'}</span>`;
  updateHeadings();
}
function filterServers(servers){const q=($('server-search')?.value||'').toLowerCase().trim();return servers.filter(s=>!q||[s.name,s.hostname,s.identifier,s.language].join(' ').toLowerCase().includes(q));}
async function loadServers(){const data=await api('/api/servers');state.servers=data.servers||[];renderServers();}
function renderAdmins(){
  $('admin-list').innerHTML=state.admins.map(a=>`<div class="admin-row"><div class="avatar">${safeText(a.username[0].toUpperCase())}</div><div class="admin-info"><strong>${safeText(a.username)}</strong><small>${tr('admin_created_at')}: ${fmtDate(a.created_at)}</small></div>${a.id===state.admin.id?`<span class="current-tag">${tr('current')}</span>`:''}</div>`).join('');
}
async function loadAdmins(){const data=await api('/api/admins');state.admins=data.admins||[];renderAdmins();}
async function loadConfig(){
  const c=await api('/api/config');state.config=c;$('domain-suffix').textContent='.'+(c.cloudflare.base_domain||'yourdomain.com');
  const p=c.pterodactyl, f=c.cloudflare;
  $('config-checklist').innerHTML=[['PTERO_PANEL_URL',!!p.panel_url],['PTERO_APP_API_KEY',p.configured],['PTERO_OWNER_ID',p.owner_id_set],['PTERO_NODE_ID',p.node_id_set],['PTERO_EGG_PYTHON_ID',p.python_egg_set],['PTERO_EGG_NODEJS_ID',p.nodejs_egg_set],['CF_API_TOKEN',f.configured],['CF_BASE_DOMAIN',!!f.base_domain]].map(([label,ok])=>`<div class="config-item ${ok?'ready':''}"><i></i>${label}</div>`).join('');
  const tunnelReady=f.configured; $('sidebar-tunnel-status').innerHTML=`<i class="status-dot ${tunnelReady?'good':'bad'}"></i><span>${tunnelReady?'Cloudflare configured':'Setup required'}</span>`;
}
async function testIntegrations(){
  $('test-integrations').disabled=true;
  try{const r=await api('/api/integrations/test');
    $('ptero-status').className=`integration-status ${r.pterodactyl.ok?'good':'bad'}`;$('ptero-status').innerHTML=`<i></i><span>${safeText(r.pterodactyl.message)}</span>`;
    $('cf-status').className=`integration-status ${r.cloudflare.ok?'good':'bad'}`;$('cf-status').innerHTML=`<i></i><span>${safeText(r.cloudflare.message)}</span>`;
    toast(r.pterodactyl.ok&&r.cloudflare.ok?'All integrations connected':'Some integrations need attention',r.pterodactyl.ok&&r.cloudflare.ok?'success':'error');
  }catch(e){toast(e.message,'error')}finally{$('test-integrations').disabled=false;}
}
function openModal(id){$(id).classList.remove('hidden')}
function closeModal(id){$(id).classList.add('hidden')}
function bindEvents(){
  $('language-toggle').addEventListener('click',()=>setLanguage(state.language==='vi'?'en':'vi'));
  $('language-toggle-main').addEventListener('click',()=>setLanguage(state.language==='vi'?'en':'vi'));
  document.querySelectorAll('.nav-item').forEach(btn=>btn.addEventListener('click',()=>navigate(btn.dataset.view)));
  document.querySelectorAll('[data-go]').forEach(btn=>btn.addEventListener('click',()=>navigate(btn.dataset.go)));
  ['create-server-top','create-server-empty','create-server-list','quick-create'].forEach(id=>$(id).addEventListener('click',()=>showServerModal()));
  $('refresh-button').addEventListener('click',async()=>{try{await loadServers();toast('Refreshed')}catch(e){toast(e.message,'error')}});
  $('server-search').addEventListener('input',()=>renderServers());
  $('logout-button').addEventListener('click',async()=>{try{await api('/api/auth/logout',{method:'POST'});}catch(_){} state.admin=null;state.csrf='';renderAuth(false)});
  $('test-integrations').addEventListener('click',testIntegrations);
  $('create-admin-button').addEventListener('click',()=>{ $('admin-form-error').classList.add('hidden');$('admin-form').reset();openModal('admin-modal') });
  document.querySelectorAll('[data-close]').forEach(btn=>btn.addEventListener('click',()=>closeModal(btn.dataset.close)));
  document.querySelectorAll('.modal-backdrop').forEach(backdrop=>backdrop.addEventListener('click',e=>{if(e.target===backdrop)backdrop.classList.add('hidden')}));
  $('server-form').addEventListener('submit',submitServer);
  $('admin-form').addEventListener('submit',submitAdmin);
  $('confirm-delete').addEventListener('click',deleteServer);
  document.addEventListener('click',async(e)=>{
    const copy=e.target.closest('[data-copy]'); if(copy){try{await navigator.clipboard.writeText('https://'+copy.dataset.copy);toast('Copied: '+copy.dataset.copy)}catch(_){toast('Clipboard unavailable','error')}return;}
    const del=e.target.closest('[data-delete]');if(del){const server=state.servers.find(s=>s.id===del.dataset.delete);if(server){state.pendingDelete=server.id;$('confirm-description').textContent=tr('delete_confirm')+' '+server.name+' ('+server.hostname+')';openModal('confirm-modal')}return;}
    const reconn=e.target.closest('[data-reconnect]');if(reconn){reconn.disabled=true;try{const target=state.servers.find(s=>s.id===reconn.dataset.reconnect);const action=target&&target.tunnel_id?'reconnect':'tunnel';const result=await api(`/api/servers/${reconn.dataset.reconnect}/${action}`,{method:'POST'});toast(result.server.status==='active'?'Tunnel connected':'Connector is still pending',result.server.status==='active'?'success':'error');await loadServers()}catch(err){toast(err.message,'error')}finally{reconn.disabled=false}}
  });
}
function showServerModal(){
  $('server-form-error').classList.add('hidden');$('server-form').reset();
  $('server-memory').value=state.config?.defaults?.memory||1024;$('server-disk').value=state.config?.defaults?.disk||2048;$('server-cpu').value=state.config?.defaults?.cpu||100;
  $('domain-suffix').textContent='.'+(state.config?.cloudflare?.base_domain||'yourdomain.com');openModal('server-modal');
}
async function submitServer(e){
  e.preventDefault();const submit=$('server-submit'),error=$('server-form-error');error.classList.add('hidden');submit.disabled=true;submit.querySelector('span').textContent=tr('deploying');
  const payload={name:$('server-name').value.trim(),slug:$('server-slug').value.trim().toLowerCase(),language:document.querySelector('input[name="language"]:checked').value,memory:Number($('server-memory').value),disk:Number($('server-disk').value),cpu:Number($('server-cpu').value)};
  try{const result=await api('/api/servers',{method:'POST',body:JSON.stringify(payload)});closeModal('server-modal');await loadServers();if(result.server.status==='active')toast(tr('created'));else toast(tr('tunnel_pending'),'error');}
  catch(err){error.textContent=err.message;error.classList.remove('hidden');}
  finally{submit.disabled=false;submit.querySelector('span').textContent=tr('provision_server')}
}
async function submitAdmin(e){
  e.preventDefault();const btn=e.submitter;btn.disabled=true;$('admin-form-error').classList.add('hidden');
  try{await api('/api/admins',{method:'POST',body:JSON.stringify({username:$('new-admin-username').value,password:$('new-admin-password').value})});closeModal('admin-modal');await loadAdmins();toast(tr('admin_created'))}
  catch(err){$('admin-form-error').textContent=err.message;$('admin-form-error').classList.remove('hidden')}
  finally{btn.disabled=false}
}
async function deleteServer(){
  if(!state.pendingDelete)return;const btn=$('confirm-delete');btn.disabled=true;btn.textContent=tr('deleting');
  try{await api(`/api/servers/${state.pendingDelete}`,{method:'DELETE'});closeModal('confirm-modal');toast(tr('delete_server')+' ✓');state.pendingDelete=null;await loadServers()}
  catch(err){toast(err.message,'error')}
  finally{btn.disabled=false;btn.textContent=tr('delete_permanently')}
}
async function onAuthSubmit(e){
  e.preventDefault();const btn=$('auth-submit');btn.disabled=true;const mode=$('auth-form').dataset.mode;
  try{const data=await api(mode==='setup'?'/api/setup':'/api/auth/login',{method:'POST',body:JSON.stringify({username:$('auth-username').value,password:$('auth-password').value})});state.csrf=data.csrf;showApp(data.admin);await loadInitial();}
  catch(err){toast(err.message,'error')}
  finally{btn.disabled=false}
}
async function loadInitial(){await loadConfig();await loadServers();}
async function init(){
  bindEvents();setLanguage(state.language);$('auth-form').addEventListener('submit',onAuthSubmit);
  try{const me=await api('/api/auth/me');
    if(me.setup_required){state.setupRequired=true;renderAuth(true);return;}
    if(!me.authenticated){state.setupRequired=false;renderAuth(false);return;}
    state.csrf=me.csrf;showApp(me.admin);await loadInitial();
  }catch(e){renderAuth(false);toast(e.message,'error')}
}
init();
