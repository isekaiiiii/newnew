# AYANE HOSTING

Private, admin-only hosting control plane built around the supplied Ark v2.0 Pterodactyl theme source.

## What is included

- First-run creation of the initial Admin account. No public sign-up and no customer/user roles.
- Ability for an existing Admin to create additional Admin accounts.
- Provisioning of Python or Node.js servers through the Pterodactyl Application API.
- Automatic selection of an unused allocation from the configured Wings node.
- A named Cloudflare Tunnel and a dedicated DNS CNAME record for every provisioned server.
- A dedicated `cloudflared` connector container per tunnel, using Docker host networking to reach the node's exposed allocation port. A dashboard `active` state means Docker started the connector container; confirm the public hostname responds before treating the app itself as healthy.
- Admin controls to reconnect a tunnel and delete the Pterodactyl server, tunnel and DNS record.
- Vietnamese / English language toggle.
- Link from each Ayane server row to its full Pterodactyl server page. Apply the Ark source in `ark-theme/` to the Pterodactyl panel to use the supplied Console, Files, Startup, Databases, Backups, Schedules, Network and Settings screens.

There is no hard-coded maximum server count in Ayane. The actual number and size of servers remain constrained by the physical node, available allocations, Pterodactyl configuration and the hosting provider.

## Architecture

Ayane is the administrator-facing provisioning portal. Pterodactyl/Wings remains the container and server lifecycle engine. The provided Ark theme is a Pterodactyl client-panel theme source tree; the ZIP does not contain the full Pterodactyl Panel backend or a standalone package manifest. It is therefore retained under `ark-theme/`, not misrepresented as a complete hosting backend.

Cloudflare Tunnel is provisioned via the Cloudflare API: create a remotely-managed tunnel, set the hostname ingress rule, create a proxied CNAME pointing at `<tunnel-id>.cfargotunnel.com`, and run the tunnel connector. This follows Cloudflare's published API flow.

## Requirements

- A working Pterodactyl Panel and Wings node.
- A root/admin Pterodactyl Application API key with permissions to read nodes/allocations and eggs, and create/delete servers.
- A Pterodactyl owner user ID (normally your own Admin user) under which Ayane creates the servers.
- A Python Egg ID and a Node.js Egg ID available in the configured Nest.
- A domain added to Cloudflare, with authoritative nameservers pointed to Cloudflare.
- A Cloudflare API token with **Account → Cloudflare Tunnel → Edit** and **Zone → DNS → Edit** permissions.
- Docker on the Ayane host. Ayane uses the Docker socket to start one `cloudflared` connector container for each server tunnel.

## Deploy with Docker Compose

```bash
cp .env.example .env
nano .env
# Replace SESSION_SECRET with: openssl rand -hex 48
# Fill in the PTERO_* and CF_* values before creating any servers.
docker compose up -d --build
```

The web app binds to `127.0.0.1:8088`. Put it behind an HTTPS reverse proxy (Nginx/Caddy) and proxy to `http://127.0.0.1:8088`. Keep the app private. For local-only HTTP testing, set `COOKIE_SECURE=false`; use `COOKIE_SECURE=true` when serving over HTTPS.

Open your Ayane URL. On first run, create the initial Admin account. After setup, only authenticated Admin accounts can access the API.

## Pterodactyl values

- `PTERO_PANEL_URL`: the base URL of your Pterodactyl panel, without a trailing slash.
- `PTERO_APP_API_KEY`: Application API key from the Pterodactyl admin area.
- `PTERO_OWNER_ID`: the Pterodactyl user ID that should own the created servers.
- `PTERO_NODE_ID`: the node where servers will be deployed.
- `PTERO_NEST_ID`: Nest containing your Python and Node.js Eggs.
- `PTERO_EGG_PYTHON_ID` / `PTERO_EGG_NODEJS_ID`: the specific Egg IDs for those runtimes.
- `PTERO_ORIGIN_HOST`: host address that a host-networked `cloudflared` container can use to reach the published Wings allocation. On a single-VPS setup where Wings exposes allocated ports on the host, `127.0.0.1` is normally the first value to try. Verify it on your own Wings networking configuration.

Ayane reads each Egg's Docker image, startup command and default environment variables from Pterodactyl. It also writes the selected allocation port into Egg variables named `PORT`, `SERVER_PORT` or `APP_PORT` when present. Confirm your Eggs bind the web process to `0.0.0.0` and use the assigned port.

## Cloudflare values

- `CF_API_TOKEN`: token with the permissions listed above.
- `CF_ACCOUNT_ID`: Cloudflare account ID.
- `CF_ZONE_ID`: zone ID for the domain.
- `CF_BASE_DOMAIN`: the domain suffix used for every server, e.g. `example.com`. A server slug `bot-01` becomes `bot-01.example.com`.

**Important for your previous DuckDNS hostname:** `ayanecute.duckdns.org` is a DuckDNS subdomain, not a Cloudflare zone that you control. Cloudflare's API cannot create `bot.ayanecute.duckdns.org` records in the `duckdns.org` zone for you. To have stable per-server hostnames via Cloudflare Tunnel, use a domain you can add to Cloudflare and point its nameservers to Cloudflare (for example, `yourdomain.com`). With no such domain, Cloudflare Quick Tunnels can provide temporary `trycloudflare.com` hostnames, but they are not stable custom subdomains.

## Runtime / capacity notes

- In the create form, RAM, disk and CPU are per-server Pterodactyl limits. A value of `0` means unlimited for that resource at the server level. It does **not** create more physical RAM, disk, CPU or free ports.
- Ayane has no arbitrary server-count cap. Pterodactyl and Wings still enforce node capacity and allocation availability.
- Python/Node.js are selected when a server is created. To change the runtime of an existing instance, use an appropriate Egg migration/reinstall workflow in Pterodactyl; changing the Egg can be destructive and is deliberately not silently automated by Ayane.
- The full Ark management experience is opened via each server's **Open Panel** action. The original ZIP is a set of Pterodactyl overlay files rather than a standalone application; apply it to the Pterodactyl panel source and build that panel as required by your installed Pterodactyl version.

**Pterodactyl login boundary:** Ayane Admin accounts are stored in Ayane and are not automatically mirrored to Pterodactyl users in this v1. The **Open Panel** action opens the corresponding Pterodactyl server page, but the browser must also have a Pterodactyl session whose user is allowed to access that server. This package does not claim to provide SSO or create a separate Pterodactyl identity for every Ayane Admin.

## Security

- The Docker socket mounted into Ayane is effectively host-level administrative access. Anyone who compromises the Ayane app could control Docker on the VPS. Do not expose this app to public registration; use HTTPS, strong unique Admin passwords, firewall restrictions and keep the container updated.
- Restrict the Pterodactyl Application API key to only the required operations where your Pterodactyl version supports permission scoping. Do not paste API keys into browser code or commit `.env` to Git.
- Back up the named Docker volume `ayane-data` and your Pterodactyl database/volumes before production use.

## Troubleshooting

- **No free allocation:** add a port range to the configured node in Pterodactyl → Nodes → Allocations.
- **Pterodactyl 401/403:** verify the Application API token and its permissions.
- **Egg missing image/startup:** verify the configured Egg IDs and set a default Docker image/startup command in the Egg.
- **Tunnel has DNS but no traffic:** verify the `cloudflared` connector container is running, `PTERO_ORIGIN_HOST` can reach the Wings allocation port, the app binds to `0.0.0.0`, and outbound UDP/TCP port 7844 is allowed.
- **Cloudflare DNS error:** check the Zone ID, that the hostname belongs to `CF_BASE_DOMAIN`, and that the API token has DNS Edit on that zone.
