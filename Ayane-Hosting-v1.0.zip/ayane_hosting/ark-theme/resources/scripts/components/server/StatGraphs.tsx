import React, {useCallback, useEffect, useState} from 'react';
import Chart, {ChartConfiguration} from 'chart.js';
import {ServerContext} from '@/state/server';
import {bytesToHuman, bytesToMegabytes} from '@/helpers';
import merge from 'deepmerge';
import tw from 'twin.macro';
import useWebsocketEvent from '@/plugins/useWebsocketEvent';
import {SocketEvent, SocketRequest} from '@/components/server/events';
import ErrorBoundary from '@/components/elements/ErrorBoundary';

interface Stats {
  memory: number;
  cpu: number;
  disk: number;
}

const chartDefaults = (ticks?: Chart.TickOptions | undefined): ChartConfiguration => ({
  type: 'line',
  options: {
    legend: {
      display: false,
    },
    tooltips: {
      enabled: false,
    },
    animation: {
      duration: 0,
    },
    elements: {
      point: {
        radius: 0,
      },
      line: {
        tension: 0.3,
        backgroundColor: 'rgba(28, 212, 168, 0.45)',
        borderColor: 'rgb(28, 212, 168)',
      },
    },
    scales: {
      xAxes: [{
        ticks: {
          display: false,
        },
        gridLines: {
          display: false,
        },
      }],
      yAxes: [{
        gridLines: {
          drawTicks: false,
          color: 'rgba(229, 232, 235, 0.15)',
          zeroLineColor: 'rgba(28, 212, 168, 0.45)',
          zeroLineWidth: 3,
        },
        ticks: merge(ticks || {}, {
          fontSize: 10,
          fontFamily: '"IBM Plex Mono", monospace',
          fontColor: 'rgb(229, 232, 235)',
          min: 0,
          beginAtZero: true,
          maxTicksLimit: 5,
        }),
      }],
    },
  },
  data: {
    labels: Array(20).fill(''),
    datasets: [
      {
        fill: true,
        data: Array(20).fill(0),
      },
    ],
  },
});

export default () => {
  const status = ServerContext.useStoreState(state => state.status.value);
  const limits = ServerContext.useStoreState(state => state.server.data!.limits);
  const [stats, setStats] = useState<Stats>({ memory: 0, cpu: 0, disk: 0 });
  const connected = ServerContext.useStoreState(state => state.socket.connected);
  const instance = ServerContext.useStoreState(state => state.socket.instance);
  const isTransferring = ServerContext.useStoreState(state => state.server.data ?.isTransferring || false);

  const diskLimit = (limits.disk);
  const memoryLimit = (limits.memory);
  const cpuLimit = (limits.cpu);

  const statsListener = (data: string) => {
    let stats: any = {};
    try {
      stats = JSON.parse(data);
    } catch (e) {
      return;
    }

    setStats({
      memory: stats.memory_bytes,
      cpu: stats.cpu_absolute,
      disk: stats.disk_bytes,
    });
  };

  useEffect(() => {
    if (!connected || !instance) {
      return;
    }

    instance.addListener(SocketEvent.STATS, statsListener);
    instance.send(SocketRequest.SEND_STATS);

    return () => {
      instance.removeListener(SocketEvent.STATS, statsListener);
    };
  }, [instance, connected]);

  const [memory, setMemory] = useState<Chart>();
  const [cpu, setCpu] = useState<Chart>();
  const [disk, setDisk] = useState<Chart>();

  const memoryRef = useCallback<(node: HTMLCanvasElement | null) => void>(node => {
    if (!node) {
      return;
    }

    setMemory(
      new Chart(node.getContext('2d')!, chartDefaults({
        callback: (value) => `${value}Mb  `,
        suggestedMax: limits.memory,
      })),
    );
  }, []);

  const cpuRef = useCallback<(node: HTMLCanvasElement | null) => void>(node => {
    if (!node) {
      return;
    }

    setCpu(
      new Chart(node.getContext('2d')!, chartDefaults({
        callback: (value) => `${value}%  `,
      })),
    );
  }, []);

  const diskRef = useCallback<(node: HTMLCanvasElement | null) => void>(node => {
    if (!node) {
      return;
    }

    setDisk(
      new Chart(node.getContext('2d')!, chartDefaults({
        callback: (value) => `${value}Mb  `,
      })),
    );
  }, []);

  useWebsocketEvent(SocketEvent.STATS, (data: string) => {
    let stats: any = {};
    try {
      stats = JSON.parse(data);
    } catch (e) {
      return;
    }

    if (memory && memory.data.datasets) {
      const data = memory.data.datasets[0].data!;

      data.push(bytesToMegabytes(stats.memory_bytes));
      data.shift();

      memory.update({ lazy: true });
    }

    if (cpu && cpu.data.datasets) {
      const data = cpu.data.datasets[0].data!;

      data.push(((stats.cpu_absolute as any) / (`${cpuLimit}` as any) * 100).toFixed(2) as any);
      data.shift();

      cpu.update({ lazy: true });
    }

    if (disk && disk.data.datasets) {
      const data = disk.data.datasets[0].data!;

      data.push(bytesToMegabytes(stats.disk_bytes));
      data.shift();

      disk.update({ lazy: true });
    }
  });

  return (
  <ErrorBoundary>
    <div className="statContainer" css={tw`grid gap-4 p-3 mb-1`}>
      <div css={tw`flex flex-row items-center`}>
        <div css={tw`flex w-28 flex-col mr-4`}>
          <span css={tw`text-xs text-gray-50`}>CPU</span>
          {status !== 'offline' ?
            <span css={tw`text-xl text-white`}>{((stats.cpu as any) / (`${cpuLimit}` as any) * 100).toFixed(2) + '%'}</span>
            :
            <span css={tw`text-xl uppercase text-white`}>Offline</span>
          }
        </div>
        {status !== 'offline' ?
          <div className="statGraphs" css={tw`w-1/2 h-full`}>
            <canvas
              id={'cpu_chart'}
              ref={cpuRef}
              aria-label={'Server CPU Usage Graph'}
              role={'img'}
            />
          </div>
          :
          null
        }
      </div>
      <div css={tw`flex flex-row items-center`}>
        <div css={tw`flex w-28 flex-col mr-4`}>
          <span css={tw`text-xs text-gray-50`}>RAM</span>
          {status !== 'offline' ?
            <span css={tw`text-xl text-white`}>{bytesToHuman(stats.memory)}</span>
            :
            <span css={tw`text-xl uppercase text-white`}>Offline</span>
          }
        </div>
        {status !== 'offline' ?
          <div className="statGraphs" css={tw`w-1/2 h-full`}>
            <canvas
              id={'memory_chart'}
              ref={memoryRef}
              aria-label={'Server Memory Usage Graph'}
              role={'img'}
            />
          </div>
          :
          null
        }
      </div>
      <div css={tw`flex flex-row items-center`}>
        <div css={tw`flex w-28 flex-col mr-4`}>
          <span css={tw`text-xs w-1/2 text-gray-50`}>DISK</span>
          {status !== 'offline' ?
            <span css={tw`text-xl text-white`}>{bytesToHuman(stats.disk)}</span>
            :
            <span css={tw`text-xl uppercase text-white`}>Offline</span>
          }
        </div>
        {status !== 'offline' ?
          <div className="statGraphs" css={tw`w-1/2 h-full`}>
            <canvas
              id={'disk_chart'}
              ref={diskRef}
              aria-label={'Server Disk Usage Graph'}
              role={'img'}
            />
          </div>
          :
          null
        }
      </div>
    </div>
  </ErrorBoundary>
  );
};
