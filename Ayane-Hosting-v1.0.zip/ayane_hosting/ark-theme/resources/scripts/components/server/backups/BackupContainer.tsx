import React, {useContext, useEffect, useState} from 'react';
import Spinner from '@/components/elements/Spinner';
import useFlash from '@/plugins/useFlash';
import Can from '@/components/elements/Can';
import CreateBackupButton from '@/components/server/backups/CreateBackupButton';
import FlashMessageRender from '@/components/FlashMessageRender';
import BackupRow from '@/components/server/backups/BackupRow';
import tw from 'twin.macro';
import getServerBackups, {Context as ServerBackupContext} from '@/api/swr/getServerBackups';
import {ServerContext} from '@/state/server';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import Pagination from '@/components/elements/Pagination';

const BackupContainer = () => {
  const { page, setPage } = useContext(ServerBackupContext);
  const { clearFlashes, clearAndAddHttpError } = useFlash();
  const { data: backups, error, isValidating } = getServerBackups();

  const backupLimit = ServerContext.useStoreState(state => state.server.data!.featureLimits.backups);

  useEffect(() => {
    if (!error) {
      clearFlashes('backups');

      return;
    }

    clearAndAddHttpError({ error, key: 'backups' });
  }, [error]);

  return (
    <ServerContentBlock title={'Backups'}>
      <FlashMessageRender byKey={'backups'} css={tw`mb-4`} />
      <div css={tw`mb-6`}>
        <div css={tw`flex justify-between flex-row mb-2`}>
          <h1 css={tw`text-white text-sm`}>Backup Usage</h1>
          {backups ?
            <h3 css={tw`text-blue-50 text-sm`}>{backups.pagination.total}/{backupLimit}</h3>
            :
            <h3 css={tw`text-blue-50 text-sm`}>0/{backupLimit}</h3>
          }
        </div>
        {backups &&
        <div css={tw`flex flex-row h-5 rounded-lg bg-neutral-915 w-full`}>
          <div css={tw`rounded-lg bg-blue-50`} style={{ width: `${((`${backups.pagination.total}` as any) / (`${backupLimit}` as any) * 100).toFixed(2) + '%'}` }}></div>
        </div>
        }
      </div>
      {backups ?
        <Pagination data={backups} onPageSelect={setPage}>
          {({ items }) => (
            !items.length ?
              // Don't show any error messages if the server has no backups and the user cannot
              // create additional ones for the server.
              !backupLimit ?
                null
                :
                <p css={tw`text-center text-sm text-white`}>
                  {page > 1 ?
                    'Looks like we\'ve run out of backups to show you, try going back a page.'
                    :
                    'It looks like there are no backups currently stored for this server.'
                  }
                </p>
              :
              items.map((backup, index) => <BackupRow
                key={backup.uuid}
                backup={backup}
                css={index > 0 ? tw`mt-2` : undefined}
              />)
          )}
        </Pagination>
        :
        <Spinner size={'large'} centered />
      }
      {backupLimit === 0 &&
        <p css={tw`text-center text-sm text-white`}>
          Backups cannot be created for this server because the backup limit is set to 0.
            </p>
      }
      {backups &&
        <Can action={'backup.create'}>
          <div css={tw`mt-6 sm:flex items-center justify-end`}>
            {(backupLimit > 0 && backups.pagination.total > 0) &&
              <p css={tw`text-sm text-white mb-4 sm:mr-6 sm:mb-0`}>
                {backups.pagination.total} of {backupLimit} backups have been created for this server.
                    </p>
            }
            {backupLimit > 0 && backupLimit !== backups.pagination.total &&
              <CreateBackupButton css={tw`w-full sm:w-auto`} />
            }
          </div>
        </Can>
      }
    </ServerContentBlock>
  );
};

export default () => {
  const [page, setPage] = useState<number>(1);
  return (
    <ServerBackupContext.Provider value={{ page, setPage }}>
      <BackupContainer />
    </ServerBackupContext.Provider>
  );
};
