import React, {lazy, memo} from 'react';
import {ServerContext} from '@/state/server';
import Can from '@/components/elements/Can';
import tw from 'twin.macro';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import isEqual from 'react-fast-compare';
import PowerControls from '@/components/server/PowerControls';
import { EulaModalFeature} from '@feature/index';
import ErrorBoundary from '@/components/elements/ErrorBoundary';
import Spinner from '@/components/elements/Spinner';

export type PowerAction = 'start' | 'stop' | 'restart' | 'kill';

const ChunkedConsole = lazy(() => import(/* webpackChunkName: "console" */'@/components/server/Console'));
const ChunkedStatGraphs = lazy(() => import(/* webpackChunkName: "graphs" */'@/components/server/StatGraphs'));

const ServerConsole = () => {
  const eggFeatures = ServerContext.useStoreState(state => state.server.data!.eggFeatures, isEqual);

  return (
    <ServerContentBlock title={'Console'}>
      <div css={tw`flex flex-wrap`}>
        <div css={tw`w-full mt-4 lg:mt-0 lg:pl-4`}>
          <Spinner.Suspense>
            <ErrorBoundary>
            <ChunkedStatGraphs />
              <ChunkedConsole />
              <Can action={['control.start', 'control.stop', 'control.restart']} matchAny>
                <PowerControls />
              </Can>
            </ErrorBoundary>
          </Spinner.Suspense>
          {eggFeatures.includes('eula') &&
            <React.Suspense fallback={null}>
              <EulaModalFeature />
            </React.Suspense>
          }
        </div>
      </div>
    </ServerContentBlock>
  );
};

export default memo(ServerConsole, isEqual);
