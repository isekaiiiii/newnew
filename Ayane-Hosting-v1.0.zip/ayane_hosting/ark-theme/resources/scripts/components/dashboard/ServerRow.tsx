import React, { memo, useEffect, useRef, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEthernet, faHdd, faMemory, faMicrochip, faServer } from '@fortawesome/free-solid-svg-icons';
import { Link } from 'react-router-dom';
import { Server } from '@/api/server/getServer';
import getServerResourceUsage, { ServerPowerState, ServerStats } from '@/api/server/getServerResourceUsage';
import { bytesToHuman, megabytesToHuman, progressFixed, formatIp } from '@/helpers';
import tw, { TwStyle } from 'twin.macro';
import GreyRowBox from '@/components/elements/GreyRowBox';
import Spinner from '@/components/elements/Spinner';
import styled from 'styled-components/macro';
import isEqual from 'react-fast-compare';
import { ServerContext } from '@/state/server';

function statusToColor(status: string | null, installing: boolean): TwStyle {
  if (installing) {
    status = '';
  }

  switch (status) {
    case 'offline':
      return tw`text-red-910`;
    case 'running':
      return tw`text-green-910`;
    default:
      return tw`text-yellow-500`;
  }
}

const StatusIndicatorBox = styled(GreyRowBox) <{ $status: ServerPowerState | undefined }>`
    ${tw`p-0 border-none bg-neutral-915`}
    display: flex;
    flex-direction: column;
    border-radius: 0.5rem;
    overflow: hidden;
`;

export default ({ server, className }: { server: Server; className?: string }) => {

  const interval = useRef<number>(null);
  const [isSuspended, setIsSuspended] = useState(server.status === 'suspended');
  const [stats, setStats] = useState<ServerStats | null>(null);
  const diskLimit = (server.limits.disk);
  const memoryLimit = (server.limits.memory);
  const cpuLimit = (server.limits.cpu);

  const getStats = () => getServerResourceUsage(server.uuid)
    .then(data => setStats(data))
    .catch(error => console.error(error));

  const isInstalling = server.status == 'installing';
  const isTransferring = server.isTransferring;

  useEffect(() => {
    setIsSuspended(stats ?.isSuspended || server.status === 'suspended');
  }, [stats ?.isSuspended, server.status]);

  useEffect(() => {
    // Don't waste a HTTP request if there is nothing important to show to the user because
    // the server is suspended.
    if (isSuspended) return;

    getStats().then(() => {
      // @ts-ignore
      interval.current = setInterval(() => getStats(), 5000);
    });

    return () => {
      interval.current && clearInterval(interval.current);
    };
  }, [isSuspended]);

  return (
    <StatusIndicatorBox as={Link} to={`/server/${server.uuid}`} $status={stats ?.status} className={className}>
      <Link css={tw`w-full bg-neutral-915`} to={`/server/${server.uuid}`}>
      {/*
        Sets the header background Image depending on Server type
        Use nestId if there are only one type of server in the nest (Minecraft)
        Use eggId if there are multiple server types in the same nest. (Source Engine)
      */}
        {server.nestId === 1 &&
          <React.Fragment>
            <header className="rowHeaderMinecraft">
              <div css={tw`flex flex-col`}>
                <h1 className="serverName">{server.name}</h1>
                <h2 className="allocation">
                  {
                    server.allocations.filter(alloc => alloc.isDefault).map(allocation => (
                      <React.Fragment key={allocation.ip + allocation.port.toString()}>
                        {allocation.alias || formatIp(allocation.ip)}:{allocation.port}
                      </React.Fragment>
                    ))
                  }
                </h2>
              </div>
              <div>
                <React.Fragment>
                  {!stats ?
                    <>
                      <span css={tw`uppercase text-lg font-bold text-white`}>
                        {server.isTransferring ?
                          'Transferring'
                          :
                          server.status === 'installing' ? 'Installing' : (
                            server.status === 'restoring_backup' ?
                              'Restoring Backup'
                              :
                              'Unavailable'
                          )
                        }
                      </span>
                    </>
                    :
                    <span css={[
                      tw`uppercase text-lg font-bold`,
                      statusToColor(stats!.status, isInstalling || isTransferring)
                    ]}>
                      {!stats ? 'Connecting...' : (isInstalling ? 'Installing' : (isTransferring) ? 'Transferring' : stats.status)}
                    </span>
                  }
                </React.Fragment>
              </div>
            </header>
          </React.Fragment>
        }
        {server.nestId === 4 &&
          <React.Fragment>
            <header className="rowHeaderRust">
              <div css={tw`flex flex-col`}>
                <h1 className="serverName">{server.name}</h1>
                <h2 className="allocation">
                  {
                    server.allocations.filter(alloc => alloc.isDefault).map(allocation => (
                      <React.Fragment key={allocation.ip + allocation.port.toString()}>
                        {allocation.alias || formatIp(allocation.ip)}:{allocation.port}
                      </React.Fragment>
                    ))
                  }
                </h2>
              </div>
              <div>
                <React.Fragment>
                  {!stats ?
                    <>
                      <span css={tw`uppercase text-lg font-bold text-white`}>
                        {server.isTransferring ?
                          'Transferring'
                          :
                          server.status === 'installing' ? 'Installing' : (
                            server.status === 'restoring_backup' ?
                              'Restoring Backup'
                              :
                              'Unavailable'
                          )
                        }
                      </span>
                    </>
                    :
                    <span css={[
                      tw`uppercase text-lg font-bold`,
                      statusToColor(stats!.status, isInstalling || isTransferring)
                    ]}>
                      {!stats ? 'Connecting...' : (isInstalling ? 'Installing' : (isTransferring) ? 'Transferring' : stats.status)}
                    </span>
                  }
                </React.Fragment>
              </div>
            </header>
          </React.Fragment>
        }
        {server.eggId === 6 &&
          <React.Fragment>
            <header className="rowHeaderArk">
              <div css={tw`flex flex-col`}>
                <h1 className="serverName">{server.name}</h1>
                <h2 className="allocation">
                  {
                    server.allocations.filter(alloc => alloc.isDefault).map(allocation => (
                      <React.Fragment key={allocation.ip + allocation.port.toString()}>
                        {allocation.alias || formatIp(allocation.ip)}:{allocation.port}
                      </React.Fragment>
                    ))
                  }
                </h2>
              </div>
              <div>
                <React.Fragment>
                  {!stats ?
                    <>
                      <span css={tw`uppercase text-lg font-bold text-white`}>
                        {server.isTransferring ?
                          'Transferring'
                          :
                          server.status === 'installing' ? 'Installing' : (
                            server.status === 'restoring_backup' ?
                              'Restoring Backup'
                              :
                              'Unavailable'
                          )
                        }
                      </span>
                    </>
                    :
                    <span css={[
                      tw`uppercase text-lg font-bold`,
                      statusToColor(stats!.status, isInstalling || isTransferring)
                    ]}>
                      {!stats ? 'Connecting...' : (isInstalling ? 'Installing' : (isTransferring) ? 'Transferring' : stats.status)}
                    </span>
                  }
                </React.Fragment>
              </div>
            </header>
          </React.Fragment>
        }
        {(!stats || isSuspended) ?
          isSuspended ?
            <div className="infoContainer2">
              <div className="infoInsideContainer2">
                <span css={tw`bg-blue-50 text-base text-center rounded px-2 py-1 text-white`}>
                  {server.status === 'suspended' ? 'Suspended' : 'Connection Error'}
                </span>
              </div>
            </div>
            :
            (server.isTransferring || server.status) ?
              <div className="infoContainer2">
                <div className="infoInsideContainer2">
                  <div css={tw`bg-blue-50 text-base text-center rounded px-2 py-1 text-white`}>
                    {server.isTransferring ?
                      'Transferring'
                      :
                      server.status === 'installing' ? 'Installing' : (
                        server.status === 'restoring_backup' ?
                          'Restoring Backup'
                          :
                          'Unavailable'
                      )
                    }
                  </div>
                </div>
              </div>
              :
              <Spinner css={tw`hidden`} size={'small'} />
          :
          <React.Fragment>
            <div className="infoContainer">
              <div className="infoInsideContainer">
                <div className="infoRow">
                  <div>
                    <h3 className="infoheader">Server ID</h3>
                    <h1 className="infoContent">{server.id}</h1>
                  </div>
                  <div>
                    <h3 className="infoheader">Type</h3>
                    {/*
                      Sets the game type text depending on the egg or nest
                      Use nestId if it is a group such as Minecraft, has multiple
                      Eggs (Paper, Forge, Vanilla) in the same Nest
                      If it is specific use the eggId such as CS:GO,
                      it is in a Nest with other egg types, such as
                      Insurgency, Team Fortress 2
                    */}
                    {server.nestId === 1 &&
                      <h1 className="infoContent">Minecraft</h1>
                    }
                    {server.nestId === 4 &&
                      <h1 className="infoContent">Rust</h1>
                    }
                    {server.eggId === 6 &&
                      <h1 className="infoContent">Ark</h1>
                    }
                    {server.eggId === 15 &&
                      <h1 className="infoContent">Node.js</h1>
                    }
                    {server.eggId === 16 &&
                      <h1 className="infoContent">Python</h1>
                    }
                  </div>
                  <div>
                    <h3 className="infoheader">Node ID</h3>
                    <h1 className="infoContent">{server.node}</h1>
                  </div>
                </div>
                <div className="infoRow">
                  <div>
                    <h3 className="infoheader">CPU</h3>
                    <div className="ProgressBar">
                      <div style={{ width: `${((stats.cpuUsagePercent as any) / (`${cpuLimit}` as any) * 100).toFixed(2) + '%'}` }} className="ProgressFill" />
                    </div>
                  </div>
                  <div>
                    <h3 className="infoheader">RAM</h3>
                    <div className="ProgressBar">
                      <div style={{ width: `${((progressFixed(stats.memoryUsageInBytes) as any) / (`${memoryLimit}` as any) * 100).toFixed(2) + '%'}` }} className="ProgressFill" />
                    </div>
                  </div>
                  <div>
                    <h3 className="infoheader">DISK</h3>
                    <div className="ProgressBar">
                      <div style={{ width: `${((progressFixed(stats.diskUsageInBytes) as any) / (`${diskLimit}` as any) * 100).toFixed(2) + '%'}` }} className="ProgressFill" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="serverRowButtonContainer">
              <Link className="serverRowButtons" to={`/server/${server.id}`}>Console</Link>
              <Link className="serverRowButtons" to={`/server/${server.id}/files`}>Files</Link>
            </div>
          </React.Fragment>
        }
      </Link>
    </StatusIndicatorBox>
  );
};
