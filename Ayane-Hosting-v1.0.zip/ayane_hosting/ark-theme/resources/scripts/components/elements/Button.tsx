import React from 'react';
import styled, { css } from 'styled-components/macro';
import tw from 'twin.macro';
import Spinner from '@/components/elements/Spinner';

interface Props {
    isLoading?: boolean;
    size?: 'xsmall' | 'small' | 'large' | 'xlarge';
    color?: 'green' | 'red' | 'primary' | 'grey' | 'arkGreen';
    isSecondary?: boolean;
}

const ButtonStyle = styled.button<Omit<Props, 'isLoading'>>`
    ${tw`relative inline-block rounded p-2 uppercase tracking-wide text-sm transition-all duration-150 border`};

    ${props => ((!props.isSecondary && !props.color) || props.color === 'primary') && css<Props>`
        ${props => !props.isSecondary && tw`bg-blue-100 border-blue-100 border text-white`};

        &:hover:not(:disabled) {
            ${tw`opacity-75 bg-blue-100 border-blue-100`};
        }
    `};

    ${props => props.color === 'grey' && css`
        ${tw`border-blue-100 bg-blue-100 text-white`};

        &:hover:not(:disabled) {
            ${tw`opacity-75 bg-blue-100 border-blue-100`};
        }
    `};

    ${props => props.color === 'green' && css<Props>`
        ${tw`border-blue-100 bg-blue-100 text-white`};

        &:hover:not(:disabled) {
            ${tw`opacity-75 bg-blue-100 border-blue-100`};
        }

        ${props => props.isSecondary && css`
            &:active:not(:disabled) {
                ${tw`opacity-75 bg-blue-100 border-blue-100`};
            }
        `};
    `};

    ${props => props.color === 'red' && css<Props>`
        ${tw`border-blue-100 bg-blue-100 text-white`};

        &:hover:not(:disabled) {
            ${tw`opacity-75 bg-blue-100 border-blue-100`};
        }

        ${props => props.isSecondary && css`
            &:active:not(:disabled) {
                ${tw`opacity-75 bg-blue-100 border-blue-100`};
            }
        `};
    `};

    ${props => props.color === 'arkGreen' && css<Props>`
        ${tw`border-blue-50 bg-blue-50 text-blue-100`};

        &:hover:not(:disabled) {
            ${tw`opacity-75 bg-blue-50 border-blue-50`};
        }

        ${props => props.isSecondary && css`
            &:active:not(:disabled) {
                ${tw`opacity-75 bg-blue-50 border-blue-50`};
            }
        `};
    `};

    ${props => props.size === 'xsmall' && tw`px-2 py-1 text-xs`};
    ${props => (!props.size || props.size === 'small') && tw`px-4 py-2`};
    ${props => props.size === 'large' && tw`p-4 text-sm`};
    ${props => props.size === 'xlarge' && tw`p-4 w-full`};

    ${props => props.isSecondary && css<Props>`
        ${tw`border-blue-100 bg-blue-100 text-white`};

        &:hover:not(:disabled) {
            ${tw`border-blue-100 opacity-75 text-white`};
            ${props => props.color === 'red' && tw`opacity-75 bg-blue-100 border-blue-100 text-white`};
            ${props => props.color === 'primary' && tw`opacity-75 bg-blue-100 border-blue-100 text-white`};
            ${props => props.color === 'green' && tw`opacity-75 bg-blue-100 border-blue-100 text-white`};
            ${props => props.color === 'arkGreen' && tw`opacity-75 bg-blue-50 border-blue-50 text-blue-100`};
        }
    `};

    &:disabled { opacity: 0.55; cursor: default }
`;

type ComponentProps = Omit<JSX.IntrinsicElements['button'], 'ref' | keyof Props> & Props;

const Button: React.FC<ComponentProps> = ({ children, isLoading, ...props }) => (
    <ButtonStyle {...props}>
        {isLoading &&
        <div css={tw`flex absolute justify-center items-center w-full h-full left-0 top-0`}>
            <Spinner size={'small'}/>
        </div>
        }
        <span css={isLoading ? tw`text-transparent` : undefined}>
            {children}
        </span>
    </ButtonStyle>
);

type LinkProps = Omit<JSX.IntrinsicElements['a'], 'ref' | keyof Props> & Props;

const LinkButton: React.FC<LinkProps> = props => <ButtonStyle as={'a'} {...props}/>;

export { LinkButton, ButtonStyle };
export default Button;
