import PageContentBlock, { PageContentBlockProps } from '@/components/elements/PageContentBlock';
import React, { useState } from 'react';
import { ServerContext } from '@/state/server';
import Can from '@/components/elements/Can';
import { faSearch } from '@fortawesome/free-solid-svg-icons';
import SubNavigation from '@/components/elements/SubNavigation';
import { NavLink } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faExternalLinkAlt } from '@fortawesome/free-solid-svg-icons';
import { useStoreState } from 'easy-peasy';
import tw, { TwStyle } from 'twin.macro';
import SearchModal from '@/components/dashboard/search/SearchModal';
import WebsocketHandler from '@/components/server/WebsocketHandler';

function statusToColor(status: string | null, installing: boolean): TwStyle {
  if (installing) {
    status = '';
  }

  switch (status) {
    case 'offline':
      return tw`bg-red-500`;
    case 'running':
      return tw`bg-green-500`;
    default:
      return tw`bg-yellow-500`;
  }
}

interface Props extends PageContentBlockProps {
  title: string;
}

export interface SubdomainResponse {
  subdomains: any[],
  domains: any[],
  ipAlias: string,
}

const ServerContentBlock: React.FC<Props> = ({ title, children, ...props }) => {
  const name = ServerContext.useStoreState(state => state.server.data!.name);
  const rootAdmin = useStoreState(state => state.user.data!.rootAdmin);
  const status = ServerContext.useStoreState(state => state.status.value);
  const id = ServerContext.useStoreState(state => state.server.data ?.id);
  const uuid = ServerContext.useStoreState(state => state.server.data ?.uuid);
  const serverId = ServerContext.useStoreState(state => state.server.data ?.internalId);
  const primaryAllocation = ServerContext.useStoreState(state => state.server.data!.allocations.filter(alloc => alloc.isDefault).map(
    allocation => (allocation.alias || allocation.ip) + ':' + allocation.port
  )).toString();
  const isInstalling = ServerContext.useStoreState(state => state.server.data!.isInstalling);
  const isTransferring = ServerContext.useStoreState(state => state.server.data!.isTransferring);
  const [visible, setVisible] = useState(false);
  return (
    <PageContentBlock title={`${name} | ${title}`} {...props}>
      {visible &&
        <SearchModal
          appear
          visible={visible}
          onDismissed={() => setVisible(false)}
        />
      }
      <WebsocketHandler />
      <div css={tw`mt-2 w-full flex flex-col pb-6`}>
        <h1 css={tw`flex flex-row items-center font-bold text-2xl text-white`}>
          <span css={tw`uppercase mr-2 text-white`}>{name}</span>
          <span css={tw`text-sm`}>
            <div
              css={[
                tw`h-4 w-4 rounded-full`,
                statusToColor(status, isInstalling || isTransferring),
              ]}
            >
            </div>
          </span>
        </h1>
        <h2 css={tw`text-sm text-gray-50`}>{primaryAllocation}</h2>
        <div css={tw`pt-2 cursor-text flex flex-row items-center text-sm`} onClick={() => setVisible(true)}>
          <div css={tw`border border-gray-50 py-1 pr-48 pl-2 opacity-50 rounded`}>
            <FontAwesomeIcon css={tw`text-gray-50 mr-2`} icon={faSearch} />
            <span css={tw`text-gray-50 text-sm`}>Search</span>
          </div>
        </div>
      </div>
      <SubNavigation>
        <div>
          <NavLink to={`/server/${id}`} exact>Console</NavLink>
          <Can action={'file.*'}>
            <NavLink to={`/server/${uuid}/files`}>File Manager</NavLink>
          </Can>
          <Can action={'user.*'}>
            <NavLink to={`/server/${uuid}/users`}>Users</NavLink>
          </Can>
          <Can action={'database.*'}>
            <NavLink to={`/server/${uuid}/databases`}>Databases</NavLink>
          </Can>
          <Can action={'backup.*'}>
            <NavLink to={`/server/${uuid}/backups`}>Backups</NavLink>
          </Can>
          <Can action={'schedule.*'}>
            <NavLink to={`/server/${uuid}/schedules`}>Schedules</NavLink>
          </Can>
          <Can action={'allocation.*'}>
            <NavLink to={`/server/${uuid}/network`}>Network</NavLink>
          </Can>
          <Can action={'startup.*'}>
            <NavLink to={`/server/${uuid}/startup`}>Startup</NavLink>
          </Can>
          <Can action={['settings.*', 'file.sftp']} matchAny>
            <NavLink to={`/server/${uuid}/settings`}>Settings</NavLink>
          </Can>
          {rootAdmin &&
            <a href={'/admin/servers/view/' + serverId} rel="noreferrer" target={'_blank'}>
              <FontAwesomeIcon icon={faExternalLinkAlt} />
            </a>
          }
        </div>
      </SubNavigation>
      <div css={tw`mt-8`}>
        {children}
      </div>
    </PageContentBlock>
  );
};

export default ServerContentBlock;
