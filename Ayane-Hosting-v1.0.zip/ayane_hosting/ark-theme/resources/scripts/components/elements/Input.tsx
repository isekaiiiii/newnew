import styled, { css } from 'styled-components/macro';
import tw from 'twin.macro';

export interface Props {
    isLight?: boolean;
    hasError?: boolean;
}

const light = css<Props>`
    ${tw`bg-transparent border-white text-white`};
    &:focus { ${tw`border-blue-50`} }

    &:disabled {
        ${tw`bg-transparent border-blue-50`};
    }
`;

const checkboxStyle = css<Props>`
    ${tw`bg-transparent cursor-pointer appearance-none inline-block align-middle select-none flex-shrink-0 w-4 h-4 text-white border border-white rounded-sm`};
    color-adjust: exact;
    background-origin: border-box;
    transition: all 75ms linear, box-shadow 25ms linear;

    &:checked {
        ${tw`bg-blue-50`};
    }

    &:focus {
        ${tw`outline-none border-white`};
    }
`;

const inputStyle = css<Props>`
    // Reset to normal styling.
    resize: none;
    ${tw`appearance-none outline-none w-full min-w-0`};
    ${tw`p-2 border rounded text-sm transition-all duration-150`};
    ${tw`bg-transparent border-white hover:border-blue-50 text-white shadow-none focus:ring-0`};

    & + .input-help {
        ${tw`mt-1 text-xs`};
        ${props => props.hasError ? tw`text-blue-50` : tw`text-white`};
    }

    &:required, &:invalid {
        ${tw`shadow-none`};
    }

    &:not(:disabled):not(:read-only):focus {
        ${tw`shadow-md border-blue-50`};
        ${props => props.hasError && tw`border-blue-50`};
    }

    &:disabled {
        ${tw`opacity-75`};
    }

    ${props => props.isLight && light};
    ${props => props.hasError && tw`text-blue-50 border-blue-50 hover:border-white`};
`;

const Input = styled.input<Props>`
    &:not([type="checkbox"]):not([type="radio"]) {
        ${inputStyle};
    }

    &[type="checkbox"], &[type="radio"] {
        ${checkboxStyle};

        &[type="radio"] {
            ${tw`rounded-full`};
        }
    }
`;
const Textarea = styled.textarea<Props>`${inputStyle}`;

export { Textarea };
export default Input;
