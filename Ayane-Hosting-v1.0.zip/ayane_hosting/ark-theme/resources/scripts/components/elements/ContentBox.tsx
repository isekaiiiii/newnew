import React from 'react';
import FlashMessageRender from '@/components/FlashMessageRender';
import tw from 'twin.macro';

type Props = Readonly<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement> & {
    title?: string;
    borderColor?: string;
    showFlashes?: string | boolean;
    showLoadingOverlay?: boolean;
}>;

const ContentBox = ({ title, borderColor, showFlashes, showLoadingOverlay, children, ...props }: Props) => (
    <div {...props}>
        {title && <h2 css={tw`text-white mb-4 px-4 text-2xl`}>{title}</h2>}
        {showFlashes &&
        <FlashMessageRender
            byKey={typeof showFlashes === 'string' ? showFlashes : undefined}
            css={tw`mb-4`}
        />
        }
        <div
            css={[
                tw`bg-neutral-920 p-4 rounded shadow-lg relative`,
                !!borderColor && tw`border-t-4`,
            ]}
        >
            {children}
        </div>
    </div>
);

export default ContentBox;
