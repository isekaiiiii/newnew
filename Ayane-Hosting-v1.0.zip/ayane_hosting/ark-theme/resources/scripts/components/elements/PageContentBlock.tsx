import React, { useEffect, useState } from 'react';
import ContentContainer from '@/components/elements/ContentContainer';
import tw, { theme } from 'twin.macro';
import FlashMessageRender from '@/components/FlashMessageRender';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUserCircle, faCreditCard, faServer, faSignOutAlt, faUserShield, faBars } from '@fortawesome/free-solid-svg-icons';
import { Link, NavLink } from 'react-router-dom';
import { useStoreState } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import styled from 'styled-components/macro';
import SubNavigation from '@/components/elements/SubNavigation';
import http from '@/api/http';

const ActiveStuff = styled.div`
    & > a, & > .navigation-link {
        &:active, &:hover, &.active {
            box-shadow: inset -2px 0 ${theme`colors.blue.50`.toString()};
            ${tw`bg-neutral-910`}
        }
    }
`;

export interface PageContentBlockProps {
  title?: string;
  className?: string;
  showFlashKey?: string;
}

const PageContentBlock: React.FC<PageContentBlockProps> = ({ title, showFlashKey, className, children }) => {
  useEffect(() => {
    if (title) {
      document.title = title;
    }
  }, [title]);

  const rootAdmin = useStoreState((state: ApplicationStore) => state.user.data!.rootAdmin);

  const [show, setShow] = useState(false);


  const onTriggerLogout = () => {
    http.post('/auth/logout').finally(() => {
      // @ts-ignore
      window.location = '/';
    });
  };

  return (
    <>
      <div className="serverContentContainer">
        <div className="sidebar" css={tw`hidden relative inset-0 z-40 md:flex`}>
          <div css="display: flex; flex-direction: column; width: 7.5rem; height: 100%; background: linear-gradient(rgb(26, 30, 58) 0%, rgb(23, 26, 51) 58.5%);">
            <a css={tw`hover:cursor-pointer`} href="https://arknodes.com/">
              <div className="h112" css={tw`w-full p-2 hover:bg-neutral-910`}>
                <img src="https://media.discordapp.net/attachments/829559572951203861/864015923484688404/logo.png" />
              </div>
            </a>
            <ul css={tw`flex-grow`}>
              <li css={tw`w-full`}>
                <ActiveStuff>
                  <a href="/account" css={tw`opacity-60 text-neutral-40 p-8 flex flex-col items-center justify-center hover:cursor-pointer hover:bg-neutral-910`}>
                    <FontAwesomeIcon fixedWidth icon={faUserCircle} />
                    <p css={tw`text-base text-center mt-2`}>Account</p>
                  </a>
                </ActiveStuff>
              </li>
              <li css={tw`w-full`}>
                <ActiveStuff>
                  <a href="/" css={tw`opacity-60 text-neutral-40 p-8 flex flex-col items-center justify-center hover:cursor-pointer hover:bg-neutral-910`}>
                    <FontAwesomeIcon fixedWidth icon={faServer} />
                    <p css={tw`text-base text-center mt-2`}>Servers</p>
                  </a>
                </ActiveStuff>
              </li>
              <li css={tw`w-full`}>
                <ActiveStuff>
                  <a css={tw`opacity-60 text-neutral-40 p-8 flex flex-col items-center justify-center hover:cursor-pointer hover:bg-neutral-910`} href="https://billing.arknodes.com/">
                    <FontAwesomeIcon fixedWidth icon={faCreditCard} />
                    <p css={tw`text-base text-center mt-2`}>Billing</p>
                  </a>
                </ActiveStuff>
              </li>
              {rootAdmin &&
                <li css={tw`w-full`}>
                  <ActiveStuff>
                    <a css={tw`opacity-60 text-neutral-40 p-8 flex flex-col items-center justify-center hover:cursor-pointer hover:bg-neutral-910`} href={'/admin'} rel={'noreferrer'}>
                      <FontAwesomeIcon fixedWidth icon={faUserShield} />
                      <p css={tw`text-base text-center mt-2`}>Admin</p>
                    </a>
                  </ActiveStuff>
                </li>
              }
            </ul>
            <ul>
              <li css={tw`w-full`}>
                <ActiveStuff>
                  <a css={tw`opacity-60 text-neutral-40 p-8 flex flex-col items-center justify-center hover:cursor-pointer hover:bg-neutral-910`} onClick={onTriggerLogout}>
                    <FontAwesomeIcon fixedWidth icon={faSignOutAlt} />
                    <p css={tw`text-base text-center mt-2`}>Logout</p>
                  </a>
                </ActiveStuff>
              </li>
            </ul>
          </div>
        </div>
        <div className="topbar" css={tw`fixed top-0 h-20 w-full flex justify-between md:hidden`}>
          <span css={tw`flex justify-center h-full w-20 hover:bg-neutral-910`}>
            <div onClick={() => setShow(!show)} css={tw`text-5xl text-white font-normal p-4 transition duration-150 ease inline-flex items-center justify-center focus:outline-none hover:cursor-pointer`}><div css={tw`my-auto`}><span css={tw`flex items-center text-white`}><FontAwesomeIcon fixedWidth icon={faBars} /></span></div></div>
          </span>
          <span css={tw`flex justify-center h-full w-20 hover:bg-neutral-910`}>
            <div css={tw`text-5xl text-white font-normal p-4 transition duration-150 ease inline-flex items-center justify-center focus:outline-none hover:cursor-pointer`}><div css={tw`my-auto`}><span css={tw`flex items-center text-white`}><img src="https://media.discordapp.net/attachments/829559572951203861/864348425156034560/logo_1.png" /></span></div></div>
          </span>
        </div>
        {show ?
          <div css={tw`transition-all transform w-full h-full fixed z-50`}>
            <div css={tw`h-20 w-full flex justify-between`}>
              <span css={tw`flex justify-center h-full w-20 hover:bg-neutral-910`}>
                <div onClick={() => setShow(!show)} css={tw`text-5xl text-white font-normal p-4 transition duration-150 ease inline-flex items-center justify-center focus:outline-none hover:cursor-pointer`}><div css={tw`my-auto`}><span css={tw`flex items-center text-white`}><FontAwesomeIcon fixedWidth icon={faBars} /></span></div></div>
              </span>
              <span css={tw`flex justify-center h-full w-auto`}>
                <div css={tw`text-3xl text-white font-normal p-4 inline-flex items-center justify-center focus:outline-none`}><span>Navigation</span></div>
              </span>
              <span css={tw`flex justify-center h-full w-20 hover:bg-neutral-910`}>
                <div css={tw`text-5xl text-white font-normal p-4 transition duration-150 ease inline-flex items-center justify-center focus:outline-none hover:cursor-pointer`}><div css={tw`my-auto`}><span css={tw`flex items-center text-white`}></span></div></div>
              </span>
            </div>
            <div css={tw`bg-blue-100 w-full h-full`}>
              <div css={tw`w-full text-center h-full p-4`}>
                <div css={tw`w-full text-left h-full p-4`}>
                  <div className="customH" css={tw`w-full flex-col flex justify-around`}>
                    <NavLink to={`/`}>
                      <div css={tw`border-b-2 border-blue-50 my-4 w-full`}>
                        <span css={tw`text-3xl text-white w-full text-left hover:text-blue-50 active:text-blue-50`}>Server List</span>
                      </div>
                    </NavLink>
                    <NavLink to={`/account`}>
                      <div css={tw`border-b-2 border-blue-50 my-4 w-full`}>
                        <span css={tw`text-3xl text-white w-full text-left hover:text-blue-50 active:text-blue-50`}>Account</span>
                      </div>
                    </NavLink>
                    {rootAdmin &&
                      <a href={'/admin'} rel={'noreferrer'}>
                        <div css={tw`border-b-2 border-blue-50 my-4 w-full`}>
                          <span css={tw`text-3xl text-white w-full text-left hover:text-blue-50 active:text-blue-50`}>Admin</span>
                        </div>
                      </a>
                    }
                    <a href={'/auth/logout'}>
                      <div css={tw`border-b-2 border-blue-50 my-4 mb-0 w-full`}>
                        <span css={tw`text-3xl text-white w-full text-left hover:text-blue-50 active:text-blue-50`}>Logout</span>
                      </div>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          :
          null
        }
        <div css={tw`mt-20 md:mt-0`} className="contentContainer2">
          {showFlashKey &&
            <FlashMessageRender byKey={showFlashKey} css={tw`mb-4`} />
          }
          <ContentContainer css={tw`z-40 xl:mx-auto`} className="severContainer">
            {location.pathname.startsWith('/account') &&
              <SubNavigation>
                <div>
                  <a href={`/account/`}>Account</a>
                  <a href={`/account/api`}>API</a>
                </div>
              </SubNavigation>
            }
            {children}
          </ContentContainer>
          <ContentContainer css={tw`mb-4`}>
            <p css={tw`text-center text-white text-xs`}>
              &copy; {(new Date()).getFullYear()}&nbsp;
              <a
                rel={'noopener nofollow noreferrer'}
                href={'https://pterodactyl.io'}
                target={'_blank'}
                css={tw`no-underline text-white hover:text-blue-50`}
              >
                Pterodactyl Software
              </a>
            </p>
          </ContentContainer>
        </div>
      </div>
    </>
  );
};

export default PageContentBlock;
