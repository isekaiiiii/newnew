import styled from 'styled-components/macro';
import tw from 'twin.macro';

export default styled.div<{ $hoverable?: boolean }>`
    ${tw`flex rounded no-underline text-white items-center bg-neutral-920 p-4 border border-transparent transition-colors duration-150 overflow-hidden`};

    ${props => props.$hoverable !== false && tw`hover:border-blue-50`};

    & .icon {
        ${tw`rounded-full bg-white p-3`};
    }
`;
