import * as React from 'react';
import tw, { TwStyle } from 'twin.macro';
import styled from 'styled-components/macro';

export type FlashMessageType = 'success' | 'info' | 'warning' | 'error';

interface Props {
  title?: string;
  children: string;
  type?: FlashMessageType;
}

const styling = (type?: FlashMessageType): TwStyle | string => {
  switch (type) {
    case 'error':
      return tw`bg-blue-50 border-blue-50`;
    case 'info':
      return tw`bg-blue-50 border-blue-50`;
    case 'success':
      return tw`bg-blue-50 border-blue-50`;
    case 'warning':
      return tw`bg-blue-50 border-blue-50`;
    default:
      return '';
  }
};

const getBackground = (type?: FlashMessageType): TwStyle | string => {
  switch (type) {
    case 'error':
      return tw`bg-blue-100`;
    case 'info':
      return tw`bg-blue-100`;
    case 'success':
      return tw`bg-blue-100`;
    case 'warning':
      return tw`bg-blue-100`;
    default:
      return '';
  }
};

const Container = styled.div<{ $type?: FlashMessageType }>`
    ${tw`p-2 border items-center leading-normal rounded flex w-full text-sm text-blue-100`};
    ${props => styling(props.$type)};
`;
Container.displayName = 'MessageBox.Container';

const MessageBox = ({ title, children, type }: Props) => (
  <div css={tw`flex justify-center`}>
    <Container className="maxwidth1200" css={tw`mt-4 lg:inline-flex`} $type={type} role={'alert'}>
      {title &&
        <span
          className={'title'}
          css={[
            tw`flex rounded-full uppercase px-2 py-1 text-xs text-white mr-3 leading-none`,
            getBackground(type),
          ]}
        >
          {title}
        </span>
      }
      <span css={tw`mr-2 text-left flex-auto`}>
        {children}
      </span>
    </Container>
  </div>
);
MessageBox.displayName = 'MessageBox';

export default MessageBox;
