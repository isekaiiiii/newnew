import React, { forwardRef } from 'react';
import { Form } from 'formik';
import { breakpoint } from '@/theme';
import FlashMessageRender from '@/components/FlashMessageRender';
import tw, { theme } from 'twin.macro';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCreditCard } from '@fortawesome/free-solid-svg-icons';
import styled from 'styled-components/macro';

const ActiveStuff = styled.div`
    & > a, & > .navigation-link {
        &:active, &:hover, &.active {
            box-shadow: inset -2px 0 ${theme`colors.blue.50`.toString()};
        }
    }
`;

type Props = React.DetailedHTMLProps<React.FormHTMLAttributes<HTMLFormElement>, HTMLFormElement> & {
  title?: string;
}

const Container = styled.div`
    ${breakpoint('xl')`
        ${tw`w-full`}
        max-width: 450px;
    `};
`;

export default forwardRef<HTMLFormElement, Props>(({ title, ...props }, ref) => (
  <>
    <div className="mobileLogin" css="grid-template-columns: auto 1fr; display: grid; position: relative; height: 100%;">
      <div className="mobileNavigation" css="position: relative; right: auto; inset: 0px; z-index: 50;">
        <div css="display: flex; flex-direction: column; width: 7.5rem; height: 100%; background: linear-gradient(rgb(26, 30, 58) 0%, rgb(23, 26, 51) 58.5%);">
          <a css={tw`hover:cursor-pointer`} href="https://arknodes.com/">
            <div className="h112" css={tw`w-full p-2 hover:bg-neutral-910`}>
              <img src="https://media.discordapp.net/attachments/829559572951203861/864015923484688404/logo.png" />
            </div>
          </a>
          <ul css={tw`flex flex-grow`}>
            <li css={tw`w-full`}>
              <ActiveStuff>
                <a css={tw`opacity-60 text-neutral-40 p-8 flex flex-col items-center justify-center hover:cursor-pointer hover:bg-neutral-910`} href="https://billing.arknodes.com/">
                  <FontAwesomeIcon fixedWidth icon={faCreditCard} />
                  <p css={tw`text-base text-center mt-2`}>Billing</p>
                </a>
              </ActiveStuff>
            </li>
          </ul>
        </div>
      </div>
      <div className="loginContainer">
        <div css="background: linear-gradient(to right, rgba(14, 16, 31, 0) 50%, rgb(14, 16, 31) 100%);"></div>
        <Container className="login" css={tw`flex h-full justify-evenly flex-col`}>
          {title &&
            <h2 css={tw`text-3xl text-center text-neutral-100 font-medium py-4`}>
              Welcome back, traveller.
            </h2>
          }
          <FlashMessageRender css={tw`mb-2 px-1`} />
          <Form {...props} ref={ref}>
            <div className="paddingFix" css={tw`md:flex w-full px-4 rounded-lg`}>
              <div css={tw`flex-1`}>
                {props.children}
              </div>
            </div>
          </Form>
          <p css={tw`text-center text-white text-xs mt-4`}>
            &copy; 2015 - {(new Date()).getFullYear()}&nbsp;
            <a
              rel={'noopener nofollow noreferrer'}
              href={'https://pterodactyl.io'}
              target={'_blank'}
              css={tw`no-underline text-white hover:text-neutral-500`}
            >
              Pterodactyl Software
            </a>
          </p>
        </Container>
      </div>
    </div>
  </>
));
