import tw from 'twin.macro';
import { createGlobalStyle } from 'styled-components/macro';

export default createGlobalStyle`
    body {
        ${tw`font-sans bg-neutral-800 text-neutral-200`};
        letter-spacing: 0.015em;
    }

    h1, h2, h3, h4, h5, h6 {
        ${tw`font-medium tracking-normal font-header`};
    }

    p {
        ${tw`text-neutral-200 leading-snug font-sans`};
    }

.VsnbJ {
    width: 50%;
    padding-left: 0.5rem;
    padding-right: 0.5rem;
    float: left;
}

.dBBJPk {
    text-align: center;
    --tw-text-opacity: 1;
    color: rgba(255,255,255,var(--tw-text-opacity));
    font-size: 0.75rem;
    line-height: 1rem;
    position: fixed;
    bottom: 0;
    width: 89%;
}

    form {
        ${tw`m-0`};
    }

    textarea, select, input, button, button:focus, button:focus-visible {
        ${tw`outline-none`};
    }

    input[type=number]::-webkit-outer-spin-button,
    input[type=number]::-webkit-inner-spin-button {
        -webkit-appearance: none !important;
        margin: 0;
    }

    input[type=number] {
        -moz-appearance: textfield !important;
    }

    /* Scroll Bar Style */
    ::-webkit-scrollbar {
        background: none;
        width: 16px;
        height: 16px;
    }

    ::-webkit-scrollbar-thumb {
        border: solid 0 rgb(0 0 0 / 0%);
        border-right-width: 4px;
        border-left-width: 4px;
        -webkit-border-radius: 9px 4px;
        -webkit-box-shadow: inset 0 0 0 1px #9D83FF, inset 0 0 0 4px #9D83FF;
    }

    ::-webkit-scrollbar-track-piece {
        margin: 4px 0;
    }

    ::-webkit-scrollbar-thumb:horizontal {
        border-right-width: 0;
        border-left-width: 0;
        border-top-width: 4px;
        border-bottom-width: 4px;
        -webkit-border-radius: 4px 9px;
    }

    ::-webkit-scrollbar-thumb:hover {
        -webkit-box-shadow:
        inset 0 0 0 1px #9D83FF,
        inset 0 0 0 4px #9D83FF;
    }

    ::-webkit-scrollbar-corner {
        background: transparent;
    }

    .loginContainer {
        background: radial-gradient(ellipse at 22% 40%, rgba(157, 131, 255, .22), transparent 58%), linear-gradient(145deg, #101224, #0E101F);
        background-position: center;
        background-size: cover;
        background-repeat: no-repeat;
        display: grid;
        height: 100%;
        grid-template-columns: repeat(2, minmax(0px, 1fr));
    }

    .login {
      ${tw`bg-neutral-800`}
    }

    .inside {
      ${tw`bg-neutral-800`}
      line-height: 1.25rem !important;
      display: inline-block;
      position: absolute;
      padding: 0px 0.25em;
      margin-top: -0.65rem;
      margin-left: 1rem;
      z-index: 20;
    }

    .inside2 {
      ${tw`bg-neutral-920`}
      line-height: 1.25rem !important;
      display: inline-block;
      position: absolute;
      padding: 0px 0.25em;
      margin-top: -0.65rem;
      margin-left: 1rem;
      z-index: 20;
    }

    .inside2 {
      ${tw`bg-neutral-920`}
      line-height: 1.25rem !important;
      display: inline-block;
      position: absolute;
      padding: 0px 0.25em;
      margin-top: -0.65rem;
      margin-left: 1rem;
      z-index: 20;
    }

    .h112 {
      height: 112px;
    }

    .serverContentContainer {
      display: grid;
      height: calc(100% - 5rem);
      grid-template-columns: repeat(1, minmax(0px, 1fr));
      position: relative;
    }

    @media (min-width: 768px) {
      .serverContentContainer {
        grid-template-columns: auto 1fr;
        height: 100%;
      }
    }

    .contentContainer2 {
      overflow: hidden auto;
      height: 100%;
      position: relative;
      padding-left: 1rem;
      padding-right: 1rem;
    }

    .severContainer {
      max-width: 1200px;
      margin-bottom: 1rem;
      margin-top: 1.5rem;
    }

    .topbar {
      background: linear-gradient(rgb(37, 28, 66) 0%, rgb(23, 26, 51) 58.5%);
    }

    .ServerRowContainer {
    	display: grid;
    	grid-template-columns: repeat(1, minmax(0px, 1fr));
    	gap: 1rem;
    }

    @media (min-width: 1024px) {
    	.ServerRowContainer {
    		grid-template-columns: repeat(2, minmax(0px, 1fr));
    	}
    }

    .rowHeaderMinecraft {
    	background-image: url(https://cdn.arknodes.com/panel_banner/minecraft.jpg);
      background-size: cover;
      background-repeat: no-repeat;
    	padding: 1rem;
      display: flex;
      flex-direction: row;
      -webkit-box-pack: justify;
      justify-content: space-between;
      -webkit-box-align: center;
      align-items: center;
    }

    .rowHeaderRust {
      background-image: url(https://cdn.arknodes.com/panel_banner/rust.jpg);
      background-size: cover;
      background-repeat: no-repeat;
      padding: 1rem;
      display: flex;
      flex-direction: row;
      -webkit-box-pack: justify;
      justify-content: space-between;
      -webkit-box-align: center;
      align-items: center;
    }

    .rowHeaderArk {
      background-image: url(https://cdn.arknodes.com/panel_banner/ark.jpg);
      background-size: cover;
      background-repeat: no-repeat;
      padding: 1rem;
      display: flex;
      flex-direction: row;
      -webkit-box-pack: justify;
      justify-content: space-between;
      -webkit-box-align: center;
      align-items: center;
    }

    .rowHeaderNode {
      background-image: url(https://cdn.arknodes.com/panel_banner/nodejs.png);
      background-size: cover;
      background-repeat: no-repeat;
      padding: 1rem;
      display: flex;
      flex-direction: row;
      -webkit-box-pack: justify;
      justify-content: space-between;
      -webkit-box-align: center;
      align-items: center;
    }

    .rowHeaderPython {
      background-image: url(https://cdn.arknodes.com/panel_banner/python.png);
      background-size: cover;
      background-repeat: no-repeat;
      padding: 1rem;
      display: flex;
      flex-direction: row;
      -webkit-box-pack: justify;
      justify-content: space-between;
      -webkit-box-align: center;
      align-items: center;
    }

    .serverName {
    	font-size: 1rem;
      line-height: 1.5rem;
      font-weight: 500;
      --tw-text-opacity: 1;
    	color: white;
    }

    .allocation {
    	font-size: 0.875rem;
      line-height: 1.25rem;
      font-weight: 400;
      --tw-text-opacity: 1;
    	color: #CAD1D8;
    }

    .infoContainer {
    	padding: 1.25rem 1rem;
      -webkit-box-flex: 1;
      flex-grow: 1;
    	background-color: rgb(23, 26, 51);
    }

    .infoContainer2 {
    	padding: 1.25rem 1rem;
      -webkit-box-flex: 1;
    	display: flex;
    	justify-content: center;
      flex-grow: 1;
    	background-color: rgb(23, 26, 51);
    }

    .infoInsideContainer {
    	display: grid;
      grid-template-columns: repeat(2, minmax(0px, 1fr));
      gap: 1rem;
    }

    .infoRow {
    	gap: .5rem;
    	display: flex;
      flex-direction: column;
      -webkit-box-pack: justify;
      justify-content: space-between;
    }

    .infoheader {
    	--tw-text-opacity: 1;
      color: rgba(123.165,134.75,147.135,var(--tw-text-opacity));
      font-size: 0.875rem;
      line-height: 1.25rem;
    }

    .infocontent {
    	--tw-text-opacity: 1;
      color: rgba(244.825,246.845,249.875,var(--tw-text-opacity));
      font-size: 1rem;
      line-height: 1.5rem;
    }

    .infoInsideContainer2 {
    	display: grid;
    	width: 25%;
    	grid-template-columns: repeat(1, minmax(0px, 1fr));
    }

    .serverRowButtonContainer {
      display: grid;
      grid-template-columns: repeat(2, minmax(0px, 1fr));
      overflow: hidden;
    }

    .serverRowButtons {
      --tw-text-opacity: 1;
      color: rgba(123.165,134.75,147.135,var(--tw-text-opacity));
      padding: 1rem;
      display: flex;
      flex-direction: row;
      -webkit-box-align: center;
      align-items: center;
      -webkit-box-pack: center;
      justify-content: center;
      font-size: 1rem;
      line-height: 1.5rem;
      cursor: pointer;
      }

    .serverRowButtons:hover {
      background-color: rgb(36, 40, 67);
      color: white;
    }

    .ProgressBar {
      height: 0.75rem;
      border-radius: 9999px;
      background-color: rgb(18, 21, 41);
    }

    .ProgressFill {
      height: 100%;
      max-width: 100%;
      border-radius: 9999px;
      background: #9D83FF;
    }

    .customH {
      height: calc(100% - 80px);
    }

    .full {
      grid-column: 1 / span 2;
    }

    input:focus,
    select:focus,
    textarea:focus,
    button:focus {
        box-shadow: none !important;
        -moz-box-shadow: none !important;
        -webkit-box-shadow: none !important;
    }

    @media (max-width: 783px) {
      .sidebar {
        display: none;
      }
      .serverContentContainer {
        display: grid;
        height: calc(100% - 5rem);
        grid-template-columns: repeat(1,minmax(0px,1fr));
      }
      .topbar {
        display: flex;
      }
      .contentContainer2 {
        margin-top: 5rem;
      }
    }

    h1, h2, h3, h4, h5, h6 {
    letter-spacing: 0em;
    font-family: "IBM Plex Sans", Roboto, system-ui, sans-serif;
    }

    .statContainer {
      grid-template-columns: repeat(3, minmax(0px, 1fr));
    }

    @media (max-width: 1024px) {
      .statGraphs {
        display: none;
      }

      .mobileLogin {
        display: flex;
        justify-content: center;
      }

      .paddingFix {
        padding-left: 0;
        padding-right: 0;
      }

      .loginContainer {
        display: flex;
      }

      .mobileNavigation {
        display: none;
      }

      .login {
        max-width: 550px;
      }
    }

      ::placeholder { /* Chrome, Firefox, Opera, Safari 10.1+ */
        color: white !important;
        opacity: 1; /* Firefox */
      }

      :-ms-input-placeholder { /* Internet Explorer 10-11 */
        color: white !important;
      }

      ::-ms-input-placeholder { /* Microsoft Edge */
        color: white !important;
      }

      .xterm .xterm-screen,
      .xterm .xterm-viewport {
        background: #0C0E1C !important;
      }

      .CodeMirror-gutters {
        background: rgb(8, 10, 19) !important;
        border-right: 1px solid #9D83FF !important;
        color: white !important;
      }

      .CodeMirror-linenumber {
        color: white !important;
      }

      .CodeMirror-scroll {
        background: rgb(8, 10, 19) !important;
      }

      [type='checkbox']:checked, [type='checkbox']:checked:hover, [type='checkbox']:checked:focus, [type='radio']:checked:hover, [type='radio']:checked:focus {
        borer-color: white !important;
        background: #9D83FF !important;
      }

      .CreateBackupText {
        max-width: 390px;
        font-size: 0.875rem;
        line-height: 1.25rem;
        color: rgba(123.165,134.75,147.135,var(--tw-text-opacity));
        margin-bottom: 1rem;
      }

      .maxwidth1200 {
        max-width: 1200px;
      }

      .pluginGrid {
        grid-template-columns: repeat(1, minmax(0px, 1fr));
      }

      @media (min-width: 1024px) {
      .pluginGrid {
        grid-template-columns: repeat(2, minmax(0px, 1fr));
      }
    }

    .modGrid {
      display: flex;
      flex-direction: column;
    }

    @media (min-width: 1024px) {
    .modGrid {
      grid-template-columns: repeat(2, minmax(0px, 1fr));
      display: grid !important;
      }
    }

    .modGridInside {
      margin-top: .5rem;
      margin-bottom: .5rem;
    }

    @media (min-width: 1024px) {
    .modGridInside {
      margin-top: 0;
      margin-bottom: 0;
      }
    }

    .gridFill {
      grid-column: span 2;
    }

    .transferContainer {
      grid-template-columns: repeat(1, minmax(0px, 1fr));
    }

    @media (min-width: 1024px) {
    .transferContainer {
      grid-template-columns: repeat(2, minmax(0px, 1fr));
    }
  }

`;
