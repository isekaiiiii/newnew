AYANE HOSTING — Ark v2.0 theme overlay

This is the Ark source tree supplied by the user, retained as the Pterodactyl client-panel theme layer. The Ayane dashboard and Python backend live in the parent folder.

The original theme ZIP is an overlay, not a complete Pterodactyl Panel application: copy its contents into the root of the matching Pterodactyl Panel source tree, then run `yarn build:production` in that Panel checkout, following the compatibility instructions for your installed panel version.

Set the Pterodactyl site name to `AYANE HOSTING` in the Panel settings; the theme reads this name from the panel configuration. The global accent and scrollbar colors in this copy have been adjusted toward Ayane's violet palette.
