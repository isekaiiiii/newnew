import sqlite3
from pathlib import Path
from typing import Any
from contextlib import contextmanager
from .config import get_settings


def connect() -> sqlite3.Connection:
    path = get_settings().database_path
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(path, timeout=30)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys = ON')
    db.execute('PRAGMA journal_mode = WAL')
    return db


def init_db() -> None:
    with db_session() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS admins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE COLLATE NOCASE,
            password_hash TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS servers (
            id TEXT PRIMARY KEY,
            ptero_id INTEGER NOT NULL,
            identifier TEXT NOT NULL,
            name TEXT NOT NULL,
            language TEXT NOT NULL,
            hostname TEXT NOT NULL,
            memory INTEGER NOT NULL,
            disk INTEGER NOT NULL,
            cpu INTEGER NOT NULL,
            allocation_ip TEXT,
            allocation_port INTEGER,
            tunnel_id TEXT,
            dns_record_id TEXT,
            connector_name TEXT,
            panel_url TEXT,
            status TEXT NOT NULL DEFAULT 'provisioning',
            error TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_servers_created_at ON servers(created_at DESC);
        CREATE UNIQUE INDEX IF NOT EXISTS idx_servers_hostname_unique ON servers(hostname);
        ''')


@contextmanager
def db_session():
    db = connect()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def admin_count() -> int:
    with db_session() as db:
        return int(db.execute('SELECT COUNT(*) FROM admins').fetchone()[0])


def row_dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
    return dict(row) if row else None
