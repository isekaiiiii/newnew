from __future__ import annotations
import re
import secrets
import sqlite3
import time
import uuid
from datetime import datetime, timezone
from typing import Literal

from fastapi import Depends, FastAPI, HTTPException, Request, Response
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator
from starlette.middleware.sessions import SessionMiddleware

from .config import get_settings
from .database import admin_count, db_session, init_db
from .security import hash_password, verify_password
from .integrations.pterodactyl import Pterodactyl, IntegrationError
from .integrations.cloudflare import Cloudflare

cfg = get_settings()
app = FastAPI(title='Ayane Hosting API', version='1.0.0')
app.add_middleware(
    SessionMiddleware,
    secret_key=cfg.session_secret,
    session_cookie=cfg.cookie_name,
    same_site='strict',
    https_only=cfg.cookie_secure,
    max_age=60 * 60 * 12,
)
app.mount('/static', StaticFiles(directory='static'), name='static')

LOGIN_ATTEMPTS: dict[str, list[float]] = {}
USERNAME_RE = re.compile(r'^[A-Za-z0-9_-]{3,32}$')


class Credentials(BaseModel):
    username: str = Field(min_length=3, max_length=32)
    password: str = Field(min_length=12, max_length=128)

    @field_validator('username')
    @classmethod
    def valid_username(cls, value: str) -> str:
        if not USERNAME_RE.fullmatch(value):
            raise ValueError('Username chỉ gồm chữ, số, dấu gạch ngang hoặc gạch dưới.')
        return value


class LoginBody(BaseModel):
    username: str = Field(min_length=1, max_length=32)
    password: str = Field(min_length=1, max_length=128)


class CreateServerBody(BaseModel):
    name: str = Field(min_length=2, max_length=50)
    slug: str = Field(min_length=2, max_length=63)
    language: Literal['python', 'nodejs']
    memory: int = Field(default=1024, ge=0)
    disk: int = Field(default=2048, ge=0)
    cpu: int = Field(default=100, ge=0)

    @field_validator('slug')
    @classmethod
    def valid_slug(cls, value: str) -> str:
        value = value.strip().lower()
        if not re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?', value):
            raise ValueError('Subdomain không hợp lệ.')
        return value


class AdminCreateBody(Credentials):
    pass


def get_admin(request: Request):
    admin_id = request.session.get('admin_id')
    if not admin_id:
        raise HTTPException(status_code=401, detail='Bạn cần đăng nhập Admin.')
    with db_session() as db:
        row = db.execute('SELECT id, username, created_at FROM admins WHERE id = ?', (admin_id,)).fetchone()
    if not row:
        request.session.clear()
        raise HTTPException(status_code=401, detail='Phiên đăng nhập không còn hợp lệ.')
    return dict(row)


def require_csrf(request: Request) -> None:
    expected = request.session.get('csrf')
    supplied = request.headers.get('x-csrf-token', '')
    if not expected or not secrets.compare_digest(str(expected), supplied):
        raise HTTPException(status_code=403, detail='CSRF token không hợp lệ. Hãy tải lại trang.')


def public_server(row: dict) -> dict:
    return {
        'id': row['id'], 'ptero_id': row['ptero_id'], 'identifier': row['identifier'],
        'name': row['name'], 'language': row['language'], 'hostname': row['hostname'],
        'memory': row['memory'], 'disk': row['disk'], 'cpu': row['cpu'],
        'allocation_ip': row['allocation_ip'], 'allocation_port': row['allocation_port'],
        'panel_url': row['panel_url'], 'status': row['status'], 'error': row['error'],
        'created_at': row['created_at'],
    }


@app.on_event('startup')
def startup() -> None:
    if len(cfg.session_secret) < 48 or cfg.session_secret.startswith('REPLACE_') or cfg.session_secret.startswith('CHANGE_ME'):
        raise RuntimeError('Hãy đặt SESSION_SECRET ngẫu nhiên tối thiểu 48 ký tự trong file .env trước khi khởi động Ayane.')
    init_db()


@app.get('/')
def index():
    return FileResponse('static/index.html')


@app.get('/api/health')
def health():
    return {
        'ok': True,
        'pterodactyl_configured': cfg.ptero_ready,
        'cloudflare_configured': cfg.cloudflare_ready,
        'admin_setup_required': admin_count() == 0,
    }


@app.get('/api/auth/me')
def auth_me(request: Request):
    if admin_count() == 0:
        return {'authenticated': False, 'setup_required': True}
    admin_id = request.session.get('admin_id')
    if not admin_id:
        return {'authenticated': False, 'setup_required': False}
    with db_session() as db:
        row = db.execute('SELECT id, username FROM admins WHERE id = ?', (admin_id,)).fetchone()
    if not row:
        request.session.clear()
        return {'authenticated': False, 'setup_required': False}
    if not request.session.get('csrf'):
        request.session['csrf'] = secrets.token_urlsafe(32)
    return {'authenticated': True, 'setup_required': False, 'admin': dict(row), 'csrf': request.session['csrf']}


@app.post('/api/setup')
def setup_admin(body: Credentials, request: Request):
    with db_session() as db:
        db.execute('BEGIN IMMEDIATE')
        if db.execute('SELECT COUNT(*) FROM admins').fetchone()[0] != 0:
            raise HTTPException(status_code=409, detail='Admin đầu tiên đã được tạo. Hãy đăng nhập.')
        db.execute('INSERT INTO admins (username, password_hash) VALUES (?, ?)', (body.username, hash_password(body.password)))
        row = db.execute('SELECT id, username FROM admins WHERE username = ?', (body.username,)).fetchone()
    request.session.clear()
    request.session['admin_id'] = row['id']
    request.session['csrf'] = secrets.token_urlsafe(32)
    return {'ok': True, 'admin': dict(row), 'csrf': request.session['csrf']}


@app.post('/api/auth/login')
def login(body: LoginBody, request: Request):
    now = time.time()
    ip = request.client.host if request.client else 'unknown'
    recent = [stamp for stamp in LOGIN_ATTEMPTS.get(ip, []) if now - stamp < 600]
    if len(recent) >= 8:
        raise HTTPException(status_code=429, detail='Quá nhiều lần đăng nhập sai. Hãy thử lại sau 10 phút.')
    with db_session() as db:
        row = db.execute('SELECT id, username, password_hash FROM admins WHERE username = ? COLLATE NOCASE', (body.username,)).fetchone()
    if not row or not verify_password(body.password, row['password_hash']):
        recent.append(now)
        LOGIN_ATTEMPTS[ip] = recent
        raise HTTPException(status_code=401, detail='Tên đăng nhập hoặc mật khẩu không đúng.')
    LOGIN_ATTEMPTS.pop(ip, None)
    request.session.clear()
    request.session['admin_id'] = row['id']
    request.session['csrf'] = secrets.token_urlsafe(32)
    return {'ok': True, 'admin': {'id': row['id'], 'username': row['username']}, 'csrf': request.session['csrf']}


@app.post('/api/auth/logout')
def logout(request: Request, admin=Depends(get_admin)):
    require_csrf(request)
    request.session.clear()
    return {'ok': True}


@app.get('/api/config')
def get_config(admin=Depends(get_admin)):
    return {
        'brand': 'AYANE HOSTING',
        'pterodactyl': {
            'configured': cfg.ptero_ready,
            'panel_url': cfg.ptero_panel_url.rstrip('/') if cfg.ptero_ready else '',
            'owner_id_set': bool(cfg.ptero_owner_id),
            'node_id_set': bool(cfg.ptero_node_id),
            'python_egg_set': bool(cfg.ptero_egg_python_id),
            'nodejs_egg_set': bool(cfg.ptero_egg_nodejs_id),
        },
        'cloudflare': {
            'configured': cfg.cloudflare_ready,
            'base_domain': cfg.cf_base_domain,
        },
        'defaults': {
            'memory': cfg.ptero_default_memory,
            'disk': cfg.ptero_default_disk,
            'cpu': cfg.ptero_default_cpu,
        },
        'server_limit': None,
    }


@app.get('/api/servers')
def list_servers(admin=Depends(get_admin)):
    with db_session() as db:
        rows = db.execute('SELECT * FROM servers ORDER BY created_at DESC').fetchall()
    return {'servers': [public_server(dict(row)) for row in rows]}


@app.post('/api/servers', status_code=201)
async def create_server(body: CreateServerBody, request: Request, admin=Depends(get_admin)):
    require_csrf(request)
    if not cfg.ptero_ready:
        raise HTTPException(status_code=503, detail='Thiếu cấu hình Pterodactyl. Hãy hoàn tất các biến PTERO_* trong .env.')
    if not cfg.cloudflare_ready:
        raise HTTPException(status_code=503, detail='Thiếu cấu hình Cloudflare. Hãy hoàn tất CF_API_TOKEN, CF_ACCOUNT_ID, CF_ZONE_ID và CF_BASE_DOMAIN trong .env.')
    cf = Cloudflare()
    hostname = cf.hostname(body.slug)
    server_uuid = str(uuid.uuid4())

    # Reserve the hostname before calling external services. BEGIN IMMEDIATE plus
    # the unique index prevents two concurrent Admin requests from claiming it.
    try:
        with db_session() as db:
            db.execute('BEGIN IMMEDIATE')
            db.execute(
                "INSERT INTO servers "
                "(id, ptero_id, identifier, name, language, hostname, memory, disk, cpu, status) "
                "VALUES (?, 0, '', ?, ?, ?, ?, ?, ?, 'provisioning')",
                (server_uuid, body.name.strip(), body.language, hostname,
                 body.memory, body.disk, body.cpu),
            )
    except sqlite3.IntegrityError as exc:
        raise HTTPException(status_code=409, detail='Subdomain này đã được sử dụng trong Ayane.') from exc

    ptero = Pterodactyl()
    try:
        server, allocation = await ptero.create_server(
            body.name.strip(), body.language, body.memory, body.disk, body.cpu,
        )
    except IntegrationError as exc:
        with db_session() as db:
            db.execute('DELETE FROM servers WHERE id = ?', (server_uuid,))
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    allocation_ip = allocation.get('ip_alias') or allocation.get('ip') or cfg.ptero_origin_host
    allocation_port = int(allocation.get('port'))
    panel_url = f"{cfg.ptero_panel_url.rstrip('/')}/server/{server['identifier']}"
    with db_session() as db:
        db.execute(
            'UPDATE servers SET ptero_id=?, identifier=?, allocation_ip=?, allocation_port=?, panel_url=?, status=? WHERE id=?',
            (server['id'], server['identifier'], allocation_ip, allocation_port,
             panel_url, 'tunnel_provisioning', server_uuid),
        )

    try:
        tunnel = await cf.provision(body.slug, allocation_port, server_uuid)
        with db_session() as db:
            db.execute('''UPDATE servers SET tunnel_id=?, dns_record_id=?, connector_name=?, status=?, error=? WHERE id=?''',
                (tunnel['tunnel_id'], tunnel['dns_record_id'], tunnel['connector_name'], tunnel['status'], tunnel['error'], server_uuid))
    except IntegrationError as exc:
        with db_session() as db:
            db.execute('UPDATE servers SET status=?, error=? WHERE id=?', ('tunnel_failed', str(exc), server_uuid))
    with db_session() as db:
        row = db.execute('SELECT * FROM servers WHERE id = ?', (server_uuid,)).fetchone()
    return {'server': public_server(dict(row)), 'created_in_pterodactyl': True}


@app.post('/api/servers/{server_id}/tunnel')
async def provision_tunnel_again(server_id: str, request: Request, admin=Depends(get_admin)):
    require_csrf(request)
    with db_session() as db:
        row = db.execute('SELECT * FROM servers WHERE id = ?', (server_id,)).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail='Không tìm thấy server.')
    record = dict(row)
    if record.get('tunnel_id'):
        raise HTTPException(status_code=409, detail='Tunnel đã tồn tại. Hãy dùng thao tác kết nối lại.')
    # The stored hostname is slug + configured base domain. Only the left-most label is used.
    slug = record['hostname'].split('.')[0]
    try:
        tunnel = await Cloudflare().provision(slug, int(record['allocation_port']), server_id)
    except IntegrationError as exc:
        with db_session() as db:
            db.execute('UPDATE servers SET status=?, error=? WHERE id=?', ('tunnel_failed', str(exc), server_id))
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    with db_session() as db:
        db.execute('UPDATE servers SET tunnel_id=?, dns_record_id=?, connector_name=?, status=?, error=? WHERE id=?',
            (tunnel['tunnel_id'], tunnel['dns_record_id'], tunnel['connector_name'], tunnel['status'], tunnel['error'], server_id))
        updated = db.execute('SELECT * FROM servers WHERE id=?', (server_id,)).fetchone()
    return {'server': public_server(dict(updated))}


@app.post('/api/servers/{server_id}/reconnect')
async def reconnect_server(server_id: str, request: Request, admin=Depends(get_admin)):
    require_csrf(request)
    with db_session() as db:
        row = db.execute('SELECT * FROM servers WHERE id = ?', (server_id,)).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail='Không tìm thấy server.')
    record = dict(row)
    if not record.get('tunnel_id') or not record.get('connector_name'):
        raise HTTPException(status_code=409, detail='Server chưa có tunnel để kết nối lại.')
    cf = Cloudflare()
    try:
        ok, error = await cf.reconnect(record['tunnel_id'], record['connector_name'])
    except IntegrationError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    status = 'active' if ok else 'pending_connector'
    with db_session() as db:
        db.execute('UPDATE servers SET status=?, error=? WHERE id=?', (status, error, server_id))
        updated = db.execute('SELECT * FROM servers WHERE id=?', (server_id,)).fetchone()
    return {'server': public_server(dict(updated))}


@app.delete('/api/servers/{server_id}')
async def delete_server(server_id: str, request: Request, admin=Depends(get_admin)):
    require_csrf(request)
    with db_session() as db:
        row = db.execute('SELECT * FROM servers WHERE id = ?', (server_id,)).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail='Không tìm thấy server.')
    record = dict(row)
    if record.get('status') != 'cleanup_pending':
        try:
            await Pterodactyl().delete_server(int(record['ptero_id']))
        except IntegrationError as exc:
            raise HTTPException(status_code=502, detail=f'Không xóa được server trên Pterodactyl: {exc}') from exc
    cleanup_errors = await Cloudflare().cleanup(record.get('tunnel_id'), record.get('dns_record_id'), record.get('connector_name'))
    if cleanup_errors:
        with db_session() as db:
            db.execute('UPDATE servers SET status=?, error=? WHERE id=?', ('cleanup_pending', ' | '.join(cleanup_errors), server_id))
        raise HTTPException(status_code=502, detail='Server đã xóa khỏi Pterodactyl nhưng còn tài nguyên tunnel/DNS cần dọn: ' + ' | '.join(cleanup_errors))
    with db_session() as db:
        db.execute('DELETE FROM servers WHERE id = ?', (server_id,))
    return {'ok': True}


@app.get('/api/admins')
def list_admins(request: Request, admin=Depends(get_admin)):
    with db_session() as db:
        rows = db.execute('SELECT id, username, created_at FROM admins ORDER BY id ASC').fetchall()
    return {'admins': [dict(row) for row in rows]}


@app.post('/api/admins', status_code=201)
def create_admin(body: AdminCreateBody, request: Request, admin=Depends(get_admin)):
    require_csrf(request)
    try:
        with db_session() as db:
            db.execute('INSERT INTO admins (username, password_hash) VALUES (?, ?)', (body.username, hash_password(body.password)))
            row = db.execute('SELECT id, username, created_at FROM admins WHERE username = ?', (body.username,)).fetchone()
    except Exception as exc:
        if 'UNIQUE' in str(exc).upper():
            raise HTTPException(status_code=409, detail='Username Admin đã tồn tại.') from exc
        raise
    return {'admin': dict(row)}


@app.get('/api/integrations/test')
async def test_integrations(admin=Depends(get_admin)):
    results = {'pterodactyl': {'ok': False, 'message': ''}, 'cloudflare': {'ok': False, 'message': ''}}
    if cfg.ptero_ready:
        try:
            await Pterodactyl().test_connection()
            results['pterodactyl'] = {'ok': True, 'message': 'Kết nối Pterodactyl thành công.'}
        except IntegrationError as exc:
            results['pterodactyl']['message'] = str(exc)
    else:
        results['pterodactyl']['message'] = 'Chưa cấu hình đủ PTERO_*.'
    if cfg.cloudflare_ready:
        try:
            await Cloudflare().request('GET', f'accounts/{cfg.cf_account_id}/cfd_tunnel', params={'per_page': 1})
            results['cloudflare'] = {'ok': True, 'message': 'Cloudflare Tunnel API access is working.'}
        except IntegrationError as exc:
            results['cloudflare']['message'] = str(exc)
    else:
        results['cloudflare']['message'] = 'Chưa cấu hình đủ biến CF_*.'
    return results
