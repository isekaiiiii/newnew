from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file='.env', env_file_encoding='utf-8', extra='ignore')

    app_name: str = 'AYANE HOSTING'
    session_secret: str = 'CHANGE_ME_TO_A_LONG_RANDOM_SECRET'
    database_path: str = '/data/ayane.db'
    cookie_secure: bool = True
    cookie_name: str = 'ayane_admin_session'

    ptero_panel_url: str = ''
    ptero_app_api_key: str = ''
    ptero_owner_id: int = 0
    ptero_node_id: int = 0
    ptero_nest_id: int = 0
    ptero_egg_python_id: int = 0
    ptero_egg_nodejs_id: int = 0
    ptero_origin_host: str = '127.0.0.1'
    ptero_default_memory: int = 1024
    ptero_default_disk: int = 2048
    ptero_default_cpu: int = 100

    cf_api_token: str = ''
    cf_account_id: str = ''
    cf_zone_id: str = ''
    cf_base_domain: str = ''

    @property
    def ptero_ready(self) -> bool:
        return bool(
            self.ptero_panel_url and self.ptero_app_api_key and self.ptero_owner_id
            and self.ptero_node_id and self.ptero_nest_id
            and self.ptero_egg_python_id and self.ptero_egg_nodejs_id
        )

    @property
    def cloudflare_ready(self) -> bool:
        return bool(self.cf_api_token and self.cf_account_id and self.cf_zone_id and self.cf_base_domain)


@lru_cache

def get_settings() -> Settings:
    return Settings()
