from __future__ import annotations
import httpx
from typing import Any
from ..config import get_settings


class IntegrationError(RuntimeError):
    pass


class Pterodactyl:
    def __init__(self):
        self.cfg = get_settings()
        self.base = self.cfg.ptero_panel_url.rstrip('/')
        self.headers = {
            'Authorization': f'Bearer {self.cfg.ptero_app_api_key}',
            'Accept': 'application/vnd.pterodactyl.v1+json',
            'Content-Type': 'application/json',
        }

    async def request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        if not self.cfg.ptero_ready:
            raise IntegrationError('Chưa cấu hình đầy đủ kết nối Pterodactyl trong file .env.')
        url = f'{self.base}/api/application/{path.lstrip("/")}'
        try:
            async with httpx.AsyncClient(timeout=30, follow_redirects=True) as client:
                response = await client.request(method, url, headers=self.headers, **kwargs)
        except httpx.HTTPError as exc:
            raise IntegrationError(f'Không kết nối được Pterodactyl: {exc}') from exc
        if response.status_code >= 400:
            try:
                payload = response.json()
                errors = payload.get('errors') or []
                message = '; '.join(e.get('detail', e.get('code', 'API error')) for e in errors)
            except Exception:
                message = response.text[:500]
            raise IntegrationError(f'Pterodactyl API {response.status_code}: {message or response.reason_phrase}')
        if response.status_code == 204 or not response.content:
            return {}
        payload = response.json()
        return payload if isinstance(payload, dict) else {}

    async def free_allocation(self) -> dict[str, Any]:
        page = 1
        while page <= 20:
            data = await self.request(
                'GET', f'nodes/{self.cfg.ptero_node_id}/allocations',
                params={'per_page': 100, 'page': page},
            )
            for item in data.get('data', []):
                attrs = item.get('attributes', {})
                if attrs.get('assigned') is False:
                    return attrs
            pagination = data.get('meta', {}).get('pagination', {})
            if page >= pagination.get('total_pages', page):
                break
            page += 1
        raise IntegrationError('Node Pterodactyl không còn allocation/port trống. Hãy thêm allocation trong Admin → Nodes.')

    async def egg_details(self, egg_id: int) -> tuple[dict[str, Any], dict[str, str]]:
        data = await self.request(
            'GET', f'nests/{self.cfg.ptero_nest_id}/eggs/{egg_id}',
            params={'include': 'variables'},
        )
        attrs = data.get('attributes', {})
        variables: dict[str, str] = {}
        rows = attrs.get('relationships', {}).get('variables', {}).get('data', [])
        for row in rows:
            item = row.get('attributes', {})
            key = item.get('env_variable')
            if key:
                variables[key] = str(item.get('default_value') or '')
        return attrs, variables

    async def create_server(self, name: str, language: str, memory: int, disk: int, cpu: int) -> tuple[dict[str, Any], dict[str, Any]]:
        egg_id = self.cfg.ptero_egg_python_id if language == 'python' else self.cfg.ptero_egg_nodejs_id
        allocation = await self.free_allocation()
        egg, environment = await self.egg_details(egg_id)
        image = egg.get('docker_image')
        if isinstance(image, dict):
            image = next(iter(image.values()), '')
        if not image:
            raise IntegrationError(f'Egg {egg_id} chưa có Docker image mặc định.')
        startup = egg.get('startup') or ''
        if not startup:
            raise IntegrationError(f'Egg {egg_id} chưa có startup command.')
        # Common app Eggs expose one of these variables for the assigned public port.
        for key in list(environment):
            if key.upper() in {'PORT', 'SERVER_PORT', 'APP_PORT'}:
                environment[key] = str(allocation.get('port', ''))
        body = {
            'name': name,
            'user': self.cfg.ptero_owner_id,
            'egg': egg_id,
            'docker_image': image,
            'startup': startup,
            'environment': environment,
            'limits': {
                'memory': memory,
                'swap': 0,
                'disk': disk,
                'io': 500,
                'cpu': cpu,
            },
            'feature_limits': {'databases': 5, 'allocations': 5, 'backups': 5},
            'allocation': {'default': int(allocation['id'])},
            'start_on_completion': True,
        }
        created = await self.request('POST', 'servers', json=body)
        server = created.get('attributes', {})
        if not server.get('id') or not server.get('identifier'):
            raise IntegrationError('Pterodactyl không trả về ID/identifier server sau khi tạo.')
        server['node_allocation'] = allocation
        return server, allocation

    async def delete_server(self, ptero_id: int) -> None:
        await self.request('DELETE', f'servers/{ptero_id}')

    async def test_connection(self) -> bool:
        await self.request('GET', 'nodes', params={'per_page': 1})
        return True
