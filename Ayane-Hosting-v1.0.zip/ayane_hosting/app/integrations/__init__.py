"""External hosting integrations."""
