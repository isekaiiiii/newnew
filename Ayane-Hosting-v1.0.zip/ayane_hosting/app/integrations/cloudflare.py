from __future__ import annotations
import re
import httpx
from typing import Any
from ..config import get_settings
from .pterodactyl import IntegrationError

SLUG_RE = re.compile(r'^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$')
DOMAIN_RE = re.compile(r'^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$')


class Cloudflare:
    def __init__(self):
        self.cfg = get_settings()
        self.base = 'https://api.cloudflare.com/client/v4'
        self.headers = {'Authorization': f'Bearer {self.cfg.cf_api_token}', 'Content-Type': 'application/json'}

    def hostname(self, slug: str) -> str:
        if not SLUG_RE.fullmatch(slug):
            raise IntegrationError('Subdomain chỉ được gồm chữ thường, số và dấu gạch ngang (không ở đầu/cuối).')
        domain = self.cfg.cf_base_domain.strip().lower().strip('.')
        if not DOMAIN_RE.fullmatch(domain):
            raise IntegrationError('CF_BASE_DOMAIN phải là domain hợp lệ đã được thêm vào Cloudflare (ví dụ example.com).')
        hostname = f'{slug}.{domain}'
        if len(hostname) > 253:
            raise IntegrationError('Subdomain kết hợp với domain gốc vượt quá giới hạn DNS 253 ký tự.')
        return hostname

    async def request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        if not self.cfg.cloudflare_ready:
            raise IntegrationError('Chưa cấu hình Cloudflare trong file .env.')
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                response = await client.request(method, f'{self.base}/{path.lstrip("/")}', headers=self.headers, **kwargs)
        except httpx.HTTPError as exc:
            raise IntegrationError(f'Không kết nối được Cloudflare API: {exc}') from exc
        try:
            payload = response.json()
        except ValueError:
            payload = {}
        if response.status_code >= 400 or not payload.get('success', False):
            errors = payload.get('errors') or []
            detail = '; '.join(str(e.get('message', e)) for e in errors) or response.text[:400]
            raise IntegrationError(f'Cloudflare API {response.status_code}: {detail}')
        return payload


    async def provision(self, slug: str, port: int, server_ref: str) -> dict[str, Any]:
        hostname = self.hostname(slug)
        tunnel_id = None
        dns_id = None
        # UUID-derived names avoid collisions when two long slugs share a prefix.
        container_name = f'ayane-tunnel-{server_ref[:12]}'
        try:
            payload = await self.request('POST', f'accounts/{self.cfg.cf_account_id}/cfd_tunnel', json={
                'name': f'ayane-{slug[:40]}-{server_ref[:8]}', 'config_src': 'cloudflare',
            })
            tunnel = payload.get('result', {})
            tunnel_id = tunnel.get('id')
            token = tunnel.get('token')
            if not tunnel_id:
                raise IntegrationError('Cloudflare không trả về tunnel ID.')
            if not token:
                token_payload = await self.request('GET', f'accounts/{self.cfg.cf_account_id}/cfd_tunnel/{tunnel_id}/token')
                token = token_payload.get('result')
            if not token:
                raise IntegrationError('Cloudflare không trả về tunnel token.')

            await self.request('PUT', f'accounts/{self.cfg.cf_account_id}/cfd_tunnel/{tunnel_id}/configurations', json={
                'config': {'ingress': [
                    {'hostname': hostname, 'service': f'http://{self.cfg.ptero_origin_host}:{port}', 'originRequest': {}},
                    {'service': 'http_status:404'},
                ]}
            })
            dns = await self.request('POST', f'zones/{self.cfg.cf_zone_id}/dns_records', json={
                'type': 'CNAME', 'name': hostname,
                'content': f'{tunnel_id}.cfargotunnel.com', 'proxied': True, 'ttl': 1,
            })
            dns_id = (dns.get('result') or {}).get('id')
            if not dns_id:
                raise IntegrationError('Cloudflare không trả về ID bản ghi DNS sau khi tạo.')
            connector_status, connector_error = self._run_connector(token, container_name)
            return {
                'hostname': hostname, 'tunnel_id': tunnel_id, 'dns_record_id': dns_id,
                'connector_name': container_name,
                'status': 'active' if connector_status else 'pending_connector',
                'error': connector_error,
            }
        except Exception:
            # Roll back every Cloudflare resource created by this request.
            await self.cleanup(tunnel_id, dns_id, container_name if tunnel_id else None)
            raise

    def _run_connector(self, token: str, container_name: str) -> tuple[bool, str | None]:
        try:
            import docker
            client = docker.from_env()
            client.ping()
            try:
                old = client.containers.get(container_name)
                old.remove(force=True)
            except docker.errors.NotFound:
                pass
            try:
                client.images.get('cloudflare/cloudflared:latest')
            except docker.errors.ImageNotFound:
                client.images.pull('cloudflare/cloudflared', tag='latest')
            client.containers.run(
                'cloudflare/cloudflared:latest',
                command=['tunnel', '--no-autoupdate', 'run', '--token', token],
                name=container_name,
                network_mode='host',
                detach=True,
                restart_policy={'Name': 'unless-stopped'},
                read_only=True,
                cap_drop=['ALL'],
                security_opt=['no-new-privileges:true'],
            )
            return True, None
        except Exception as exc:
            return False, f'Tunnel/DNS đã tạo nhưng chưa khởi chạy được cloudflared container: {exc}'

    async def reconnect(self, tunnel_id: str, container_name: str) -> tuple[bool, str | None]:
        token_data = await self.request('GET', f'accounts/{self.cfg.cf_account_id}/cfd_tunnel/{tunnel_id}/token')
        token = token_data.get('result')
        if not token:
            return False, 'Cloudflare không trả về tunnel token.'
        return self._run_connector(token, container_name)

    async def cleanup(self, tunnel_id: str | None, dns_id: str | None, container_name: str | None) -> list[str]:
        errors = []
        if container_name:
            try:
                import docker
                client = docker.from_env()
                try:
                    client.containers.get(container_name).remove(force=True)
                except docker.errors.NotFound:
                    pass
            except Exception as exc:
                errors.append(f'Docker cleanup: {exc}')
        if dns_id:
            try:
                await self.request('DELETE', f'zones/{self.cfg.cf_zone_id}/dns_records/{dns_id}')
            except Exception as exc:
                errors.append(f'DNS cleanup: {exc}')
        if tunnel_id:
            try:
                await self.request('DELETE', f'accounts/{self.cfg.cf_account_id}/cfd_tunnel/{tunnel_id}')
            except Exception as exc:
                errors.append(f'Tunnel cleanup: {exc}')
        return errors
