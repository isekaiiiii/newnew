import base64
import hashlib
import hmac
import os

_ITERATIONS = 310_000


def hash_password(password: str) -> str:
    salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, _ITERATIONS)
    return 'pbkdf2_sha256${}${}${}'.format(
        _ITERATIONS,
        base64.urlsafe_b64encode(salt).decode().rstrip('='),
        base64.urlsafe_b64encode(digest).decode().rstrip('='),
    )


def verify_password(password: str, encoded: str) -> bool:
    try:
        scheme, iterations, salt_text, digest_text = encoded.split('$', 3)
        if scheme != 'pbkdf2_sha256':
            return False
        pad = lambda value: value + '=' * (-len(value) % 4)
        salt = base64.urlsafe_b64decode(pad(salt_text))
        expected = base64.urlsafe_b64decode(pad(digest_text))
        actual = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, int(iterations))
        return hmac.compare_digest(actual, expected)
    except (ValueError, TypeError):
        return False
